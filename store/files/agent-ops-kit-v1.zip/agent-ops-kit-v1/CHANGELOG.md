# Changelog

## v1.1.0 — 2026-11-06

- New `hooks/guard_bash.py` + `hooks/settings.example.json`: a Claude Code PreToolUse
  hook that blocks a commit while `executions/lint_secrets.py` finds a credential (or an
  un-ignored `.env`), `git commit --no-verify`, force-push (`--force-with-lease` is
  allowed), `rm -r` on `/`, `~`, `$HOME`, `*`, `.` or the project root, and ad-hoc
  `pip install <package>` (opt out with `AOK_ALLOW_ADHOC_PIP=1`). The agent sees the
  reason and the fix. Tests: `executions/tests/test_guard_bash.py` (8).
- New `cursor/rules/`: `doe-core.mdc` (always applied), `python-fastapi.mdc`,
  `linux-deploy.mdc`, so Cursor gets the rules as native project rules.
- New `stacks/fastapi-python-linux/CLAUDE.md`: stack addendum for FastAPI services.

## v1.0.1 — 2026-11-04

- `qa_website.py`: link checks run as an in-page `fetch()` (the browser's own network
  stack), with the Playwright API client only as a fallback. Before, a host with broken
  IPv6 made the API client hang, and every same-origin link was reported broken while
  the pages loaded fine. A real 404 is still reported as 404.
- New `executions/tests/test_qa_website_links.py` (4 tests) for that behaviour.

## v1.0 — 2026-10-16

- Initial release: CLAUDE.md, 4 core directives, 3 example directives, 7 execution
  scripts (template, 2 linters, anneal log, QA, deploy, scrape), tests, 3 skills,
  PM/worker agent templates, registry schema, 3 docs.

Buyers get updates by email at no charge.
