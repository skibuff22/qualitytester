# Changelog

## v1.0.1 — 2026-11-04

- `qa_website.py`: link checks run as an in-page `fetch()` (the browser's own network
  stack), with the Playwright API client only as a fallback. Before, a host with broken
  IPv6 made the API client hang, and every same-origin link was reported broken while
  the pages loaded fine. A real 404 is still reported as 404.
- New `executions/tests/test_qa_website_links.py` (4 tests) for that behaviour.

## v1.0 — 2026-10-16

- Initial release: CLAUDE.md, 4 core directives, 3 example directives, 7 execution
  scripts (template, 2 linters, anneal log, QA, deploy, scrape), tests, 3 skills,
  PM/worker agent templates, registry schema, 3 docs.

Buyers get updates by email at no charge.
