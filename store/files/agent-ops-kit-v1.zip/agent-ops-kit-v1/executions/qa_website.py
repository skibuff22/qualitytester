#!/usr/bin/env python3
"""
qa_website.py — headless-browser QA + SEO check for any site (works on SPAs).

Per page: HTTP status, <title>, meta description (50–160 chars), viewport meta,
exactly one <h1>, canonical, and same-origin links that resolve. Crawls
same-origin links up to --max-pages. Writes a Markdown report and exits 1 on FAIL.

Requires once:  pip install playwright && playwright install chromium

Usage:
  py executions/qa_website.py --url https://example.com [--max-pages 25] [--report qa.md]
  py executions/qa_website.py --url https://host/health --expect-status 200 --max-pages 1
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass, field, asdict
from urllib.parse import urljoin, urlparse, urldefrag


@dataclass
class PageResult:
    url: str
    status: int = 0
    title: str = ""
    description: str = ""
    viewport: bool = False
    h1_count: int = 0
    canonical: str = ""
    broken_links: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors


def evaluate(r: PageResult, expect_status: int) -> None:
    if r.status != expect_status:
        r.errors.append(f"status {r.status} (expected {expect_status})")
    if not r.title.strip():
        r.errors.append("missing <title>")
    elif len(r.title) > 70:
        r.warnings.append(f"title {len(r.title)} chars (>70)")
    if not r.description.strip():
        r.errors.append("missing meta description")
    elif not 50 <= len(r.description) <= 160:
        r.warnings.append(f"meta description {len(r.description)} chars (ideal 50–160)")
    if not r.viewport:
        r.errors.append("missing viewport meta")
    if r.h1_count != 1:
        r.errors.append(f"{r.h1_count} <h1> elements (need exactly 1)")
    if r.broken_links:
        r.errors.append(f"{len(r.broken_links)} broken same-origin links")


LINK_JS = """async (u) => {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), 10000);
  try { return (await fetch(u, {method: 'HEAD', redirect: 'follow', signal: c.signal})).status; }
  catch (e) { return 0; } finally { clearTimeout(t); }
}"""


def link_status(page, ctx, url: str) -> int:
    """HTTP status of a same-origin link, 0 if unreachable.

    Checked with fetch() inside the page, i.e. the browser's own network stack: it
    falls back IPv6 -> IPv4 like a visitor's browser does. Playwright's APIRequestContext
    does not; on a host with broken IPv6 it timed out on every link and reported a
    healthy site as all-broken (moneymachine A11, 2026-11-03). That client is kept
    only as a second opinion when fetch() itself fails.
    """
    try:
        status = int(page.evaluate(LINK_JS, url))
    except Exception:  # noqa: BLE001
        status = 0
    if status:
        return status
    try:
        return ctx.request.head(url, timeout=10000).status
    except Exception:  # noqa: BLE001
        return 0


def crawl(start: str, max_pages: int, expect_status: int, timeout_ms: int = 20000) -> list[PageResult]:
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("playwright not installed: pip install playwright && playwright install chromium", file=sys.stderr)
        sys.exit(2)

    def norm(u: str) -> str:
        p = urlparse(urldefrag(u)[0])
        return p._replace(path=p.path or "/").geturl()

    start = norm(start)
    origin = urlparse(start).netloc
    queue, seen, results = [start], {start}, []
    link_cache: dict[str, int] = {}

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        ctx = browser.new_context(user_agent="agent-ops-kit qa_website/1.0")
        page = ctx.new_page()
        while queue and len(results) < max_pages:
            url = queue.pop(0)
            r = PageResult(url=url)
            try:
                resp = page.goto(url, wait_until="networkidle", timeout=timeout_ms)
                r.status = resp.status if resp else 0
                r.title = page.title()
                r.description = page.evaluate("() => (document.querySelector('meta[name=\"description\"]')||{}).content || ''")
                r.viewport = bool(page.evaluate("() => !!document.querySelector('meta[name=\"viewport\"]')"))
                r.h1_count = int(page.evaluate("() => document.querySelectorAll('h1').length"))
                r.canonical = page.evaluate("() => (document.querySelector('link[rel=\"canonical\"]')||{}).href || ''")
                hrefs = page.evaluate("() => Array.from(document.querySelectorAll('a[href]')).map(a => a.href)")
                for h in hrefs:
                    h = norm(urljoin(url, h))
                    if urlparse(h).netloc != origin or urlparse(h).scheme not in ("http", "https"):
                        continue
                    if h not in link_cache:
                        link_cache[h] = link_status(page, ctx, h)
                    if link_cache[h] >= 400 or link_cache[h] == 0:
                        r.broken_links.append(h)
                    if h not in seen and len(seen) < max_pages:
                        seen.add(h)
                        queue.append(h)
            except Exception as e:  # noqa: BLE001
                r.errors.append(f"load failed: {e.__class__.__name__}: {str(e)[:120]}")
            evaluate(r, expect_status)
            results.append(r)
            print(f"{'PASS' if r.ok else 'FAIL'}  {url}" + (f"  — {'; '.join(r.errors)}" if r.errors else ""))
        browser.close()
    return results


def write_report(path: str, results: list[PageResult], start: str) -> None:
    lines = [f"# QA report — {start}", "", f"Generated {time.strftime('%Y-%m-%d %H:%M:%S')}", "",
             "| Page | Status | Title | Desc len | H1 | Viewport | Broken links | Result |", "|---|---|---|---|---|---|---|---|"]
    for r in results:
        lines.append(f"| {r.url} | {r.status} | {r.title[:40]} | {len(r.description)} | {r.h1_count} | {'y' if r.viewport else 'n'} | {len(r.broken_links)} | {'PASS' if r.ok else 'FAIL: ' + '; '.join(r.errors)} |")
    lines += ["", "## Warnings", ""] + [f"- {r.url}: {w}" for r in results for w in r.warnings] or ["- none"]
    lines += ["", "## Broken links", ""] + [f"- {r.url} → {b}" for r in results for b in r.broken_links]
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Headless QA + SEO check")
    ap.add_argument("--url", required=True)
    ap.add_argument("--max-pages", type=int, default=25)
    ap.add_argument("--expect-status", type=int, default=200)
    ap.add_argument("--report")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    results = crawl(a.url, a.max_pages, a.expect_status)
    report = a.report or f"qa_report_{urlparse(a.url).netloc.replace(':', '_')}.md"
    write_report(report, results, a.url)
    failed = [r for r in results if not r.ok]
    if a.json:
        print(json.dumps([asdict(r) for r in results], indent=2))
    print(f"QA: {'PASS' if not failed else 'FAIL'} ({len(results)} pages, {len(failed)} failed) — report: {report}")
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
