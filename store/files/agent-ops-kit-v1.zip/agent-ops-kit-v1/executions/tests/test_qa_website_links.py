"""Run: py -m pytest executions/tests
A11 (2026-11-03): qa_website link check must not report a healthy site as broken
when one HTTP client fails (Playwright APIRequestContext hung on broken IPv6)."""
import importlib.util, sys
from pathlib import Path

spec = importlib.util.spec_from_file_location(
    "qa_website", Path(__file__).resolve().parents[1] / "qa_website.py")
qa = importlib.util.module_from_spec(spec); sys.modules["qa_website"] = qa; spec.loader.exec_module(qa)


class Page:
    def __init__(self, status=None, exc=False): self.status, self.exc = status, exc
    def evaluate(self, js, url):
        if self.exc: raise RuntimeError("page closed")
        return self.status


class Resp:
    def __init__(self, s): self.status = s


class Req:
    def __init__(self, status=None, hang=False): self.status, self.hang = status, hang
    def head(self, url, timeout): 
        if self.hang: raise TimeoutError("Timeout 10000ms exceeded")
        return Resp(self.status)


class Ctx:
    def __init__(self, req): self.request = req


def test_in_page_fetch_wins_when_api_client_hangs():
    assert qa.link_status(Page(200), Ctx(Req(hang=True)), "https://x/") == 200


def test_real_404_still_reported():
    assert qa.link_status(Page(404), Ctx(Req(hang=True)), "https://x/nope") == 404


def test_api_client_is_fallback_when_fetch_fails():
    assert qa.link_status(Page(0), Ctx(Req(200)), "https://x/") == 200
    assert qa.link_status(Page(exc=True), Ctx(Req(301)), "https://x/") == 301


def test_both_fail_is_broken():
    assert qa.link_status(Page(0), Ctx(Req(hang=True)), "https://x/") == 0
