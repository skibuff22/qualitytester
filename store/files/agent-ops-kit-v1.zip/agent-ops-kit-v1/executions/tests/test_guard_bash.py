"""Run: py -m pytest executions/tests  (or: py executions/tests/test_guard_bash.py)"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

KIT = Path(__file__).resolve().parents[2]
HOOK = KIT / "hooks" / "guard_bash.py"
FAKE_STRIPE = "sk_live_" + "A1b2C3d4E5f6G7h8I9j0K1l2M3n4"   # lint-secrets: allow


def run_hook(command: str, project: Path, tool: str = "Bash", **env) -> subprocess.CompletedProcess:
    payload = {"hook_event_name": "PreToolUse", "tool_name": tool, "cwd": str(project),
               "tool_input": {"command": command}}
    e = {k: v for k, v in os.environ.items() if k != "AOK_ALLOW_ADHOC_PIP"}
    e.update(CLAUDE_PROJECT_DIR=str(project), **env)
    return subprocess.run([sys.executable, str(HOOK)], input=json.dumps(payload),
                          capture_output=True, text=True, env=e, timeout=60)


def project_with_linter(d: str) -> Path:
    p = Path(d)
    (p / "executions").mkdir()
    shutil.copy(KIT / "executions" / "lint_secrets.py", p / "executions" / "lint_secrets.py")
    (p / ".gitignore").write_text(".env\n")
    return p


def test_safe_commands_pass():
    with tempfile.TemporaryDirectory() as d:
        p = project_with_linter(d)
        for cmd in ["ls -la", "git status", "git push origin main", "git push --force-with-lease origin feat",
                    "git commit -m 'fix: n+1 query'", "rm -rf build/", "pip install -r requirements.txt",
                    "python -m pip install -e .", "pip install -U pip", "pip list", "rm notes.txt"]:
            r = run_hook(cmd, p)
            assert r.returncode == 0, (cmd, r.stderr)


def test_force_push_blocked_in_every_spelling():
    with tempfile.TemporaryDirectory() as d:
        for cmd in ["git push --force", "git push -f origin main", "git push -uf origin main",
                    "git -C repo push origin +main", "cd app && git push --force origin master"]:
            r = run_hook(cmd, Path(d))
            assert r.returncode == 2 and "force-push" in r.stderr, cmd


def test_no_verify_commit_blocked():
    with tempfile.TemporaryDirectory() as d:
        for cmd in ["git commit --no-verify -m x", "git commit -nm x"]:
            assert run_hook(cmd, project_with_linter(tempfile.mkdtemp(dir=d))).returncode == 2, cmd


def test_commit_blocked_while_a_secret_is_in_the_tree():
    with tempfile.TemporaryDirectory() as d:
        p = project_with_linter(d)
        (p / "pay.py").write_text(f'stripe.api_key = "{FAKE_STRIPE}"\n')
        r = run_hook("git add -A && git commit -m 'add payments'", p)
        assert r.returncode == 2 and "pay.py:1" in r.stderr, r.stderr
        (p / "pay.py").write_text('import os\nstripe.api_key = os.environ["STRIPE_SECRET_KEY"]\n')
        assert run_hook("git commit -m 'add payments'", p).returncode == 0


def test_commit_blocked_when_env_is_not_gitignored():
    with tempfile.TemporaryDirectory() as d:
        p = project_with_linter(d)
        (p / ".gitignore").write_text("logs/\n")
        (p / ".env").write_text("X=1\n")
        r = run_hook("git commit -m x", p)
        assert r.returncode == 2 and ".env" in r.stderr


def test_rm_of_root_home_project_or_glob_blocked():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        for cmd in ["rm -rf /", "rm -rf ~", "rm -fr $HOME", "sudo rm -r /*", "rm -rf *", f"rm -rf {p}/",
                    "rm -Rf ."]:
            r = run_hook(cmd, p)
            assert r.returncode == 2 and "blocked" in r.stderr, cmd


def test_adhoc_pip_install_blocked_unless_opted_out():
    with tempfile.TemporaryDirectory() as d:
        p = Path(d)
        for cmd in ["pip install requests", "python3 -m pip install fastapi==0.115.0", "pip3 install -U httpx"]:
            r = run_hook(cmd, p)
            assert r.returncode == 2 and "requirements" in r.stderr, cmd
        assert run_hook("pip install requests", p, AOK_ALLOW_ADHOC_PIP="1").returncode == 0


def test_other_tools_and_bad_payloads_never_block():
    with tempfile.TemporaryDirectory() as d:
        assert run_hook("rm -rf /", Path(d), tool="Write").returncode == 0
        r = subprocess.run([sys.executable, str(HOOK)], input="not json", capture_output=True, text=True)
        assert r.returncode == 0


if __name__ == "__main__":
    fns = [v for k, v in dict(globals()).items() if k.startswith("test_")]
    for fn in fns:
        fn()
    print(f"{len(fns)} passed")
