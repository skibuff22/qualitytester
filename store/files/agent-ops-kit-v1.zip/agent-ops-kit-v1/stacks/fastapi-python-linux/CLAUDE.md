# Stack addendum: FastAPI + Python + Linux

Append this section to the kit's `CLAUDE.md` (below "Environment constants") in a
FastAPI service repo. It is the Claude Code twin of `cursor/rules/python-fastapi.mdc`
and `cursor/rules/linux-deploy.mdc`; the hook in `hooks/guard_bash.py` enforces the
parts that can be checked mechanically.

## Stack rules

**Dependencies.** Add a package by pinning it in `requirements.txt` (or
`pyproject.toml`) and running `pip install -r requirements.txt` in `.venv`. Ad-hoc
`pip install <pkg>` is blocked by the hook, because the next machine will not have it.

**Configuration.** Settings come from environment variables loaded once at startup
(pydantic-settings or `os.environ`); a missing required setting fails at startup with
its name. No credentials in code, tests or fixtures; `executions/lint_secrets.py` runs
before every commit and the hook blocks the commit if it finds one.

**Endpoints.** Pydantic models on the signature for input. Caller errors raise
`HTTPException` with a specific status; never return 200 with an error body, never
catch `Exception` without logging and re-raising. No blocking I/O inside `async def`.

**Tests.** Every endpoint change gets a `TestClient` test, including one bad-input
case. A bug fix starts with a test that fails on the old code. Run
`python -m pytest -q` and quote the result line before calling the work done.

**Deploy (Linux).** Only through `executions/deploy_service.py`, then verify the live
endpoint and `journalctl -u <unit>`. Shell scripts use `set -euo pipefail`. A restart or
a rollback is recovery, not a fix.

**Git.** No force-push and no `--no-verify` (both blocked by the hook). If a pre-commit
check fails, fix what it reports.

## Mandatory directive checks (add these rows to the table)

| Area | Directive | Key rule |
|---|---|---|
| Dependencies | this section | Pin in requirements, install from the file |
| API endpoints | this section | Pydantic in, HTTPException out, a test per change |
