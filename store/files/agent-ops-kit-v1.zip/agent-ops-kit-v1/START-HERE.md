# Agent Ops Kit v1 — START HERE

The D.O.E. framework (Directive / Orchestration / Execution) for running AI coding
agents — Claude Code, Cursor, Codex, Gemini CLI — reliably on real projects.

**The problem it solves:** an LLM is probabilistic; your business logic is not.
If the agent does everything itself, errors compound: 90 % accuracy per step is
59 % over five steps. D.O.E. pushes the deterministic work into scripts and
leaves the agent exactly one job — deciding what to run next.

## 10-minute install

1. Copy these into the root of your repo:
   - `CLAUDE.md` (rename/merge if you already have one; Cursor users: use `cursor/rules/` below)
   - `directives/`  — your SOPs (keep `core/`, write your own next to `examples/`)
   - `executions/`  — deterministic scripts + linters + tests
   - `skills/`      — optional Claude Code skills (`.claude/skills/<name>/SKILL.md`)
   - `hooks/`       — the Bash guard hook; copy `hooks/settings.example.json` to
     `.claude/settings.json` (or merge its `hooks` block into yours)
   - Cursor: copy `cursor/rules/*.mdc` to `.cursor/rules/`
   - FastAPI / Python / Linux repos: append `stacks/fastapi-python-linux/CLAUDE.md` to `CLAUDE.md`
2. Run the linters once so you know the baseline:
   ```
   python executions/lint_directives.py
   python executions/lint_secrets.py
   ```
3. Write your first directive by copying `directives/00_template.md`. Name it after
   the job (`deploy_api.md`, `scrape_pricing.md`). Reference the script that will
   do the work — then write the script from `executions/00_template.py`.
4. Tell the agent: *"Read CLAUDE.md, then do X."* It will read the directive, run
   the script, and update the directive with anything it learned.

## What's in the box

| Path | What it is |
|---|---|
| `CLAUDE.md` | The agent's operating instructions: the 3 layers, the 6 operating principles, the self-annealing loop, mandatory directive checks |
| `directives/core/` | Operating principles, self-annealing loop, bug-fix standard, agent governance — written to be synced unchanged across every project you run |
| `directives/examples/` | Three complete directives (deploy a service, QA a website, scrape a site) showing the inputs → tools → outputs → edge-cases shape |
| `executions/00_template.py` | Script scaffold: argparse, `.env` loading, JSON output, exit codes, logging — everything a deterministic tool needs |
| `executions/lint_directives.py` | Fails CI if a directive is missing sections, references a script that doesn't exist, or a script has no directive |
| `executions/lint_secrets.py` | Catches hard-coded API keys / tokens before they hit git (`sk_live_`, `ghp_`, AWS, private keys…) |
| `executions/qa_website.py` | Headless-browser QA + SEO check (title, meta, viewport, H1, broken links) for any URL — works on SPAs |
| `executions/anneal.py` | Records a self-anneal entry (failure → root cause → fix → test → standard) so the system gets stronger, not just patched |
| `executions/tests/` | Tests for the linters — the kit follows its own rule: every tool has a test |
| `skills/` | Claude Code skills for QA, deploy, and project status that call the scripts above |
| `hooks/guard_bash.py` | Claude Code PreToolUse hook: blocks a commit while `lint_secrets.py` finds a key (or `.env` is not gitignored), `--no-verify`, force-push (`--force-with-lease` allowed), `rm -r` on `/`, `~`, `*` or the project root, and ad-hoc `pip install <pkg>` (opt out with `AOK_ALLOW_ADHOC_PIP=1`) |
| `cursor/rules/` | The same rules as Cursor `.mdc` files: D.O.E. core (always on), Python + FastAPI, Linux deploy |
| `stacks/fastapi-python-linux/` | CLAUDE.md addendum for FastAPI services: dependencies, settings, endpoint errors, tests, deploy |
| `agents/` | Multi-agent pattern: PM agent + worker agent templates, agent registry schema, work-authorization rules |
| `docs/` | Why D.O.E. works, adopting it in an existing codebase, running a fleet of agents |

## The three rules that matter most

1. **Fix the root cause, not the symptom.** A retry, reset, or reprocess is
   *recovery*, never a *fix*. If you can't name the mechanism that failed, keep digging.
2. **Every bug fix gets a test and a standard.** No test → the bug returns. No
   standard (directive update + lint where detectable) → the same class of bug
   appears somewhere else.
3. **Directives are living documents.** The agent updates them in the same session
   it learns something (API limits, edge cases, timing). That's how the kit compounds.

## Support

Reply to your purchase email. Bugs in the kit scripts are fixed and re-sent to all
buyers. Refunds within 14 days, no questions.

License: `LICENSE.txt` (use in unlimited projects you own or work on; don't resell the kit itself).
