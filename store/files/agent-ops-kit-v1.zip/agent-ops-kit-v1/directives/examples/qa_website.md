# Directive: QA and SEO-check a website

## Goal

Prove a site works and is search-ready after every build or deploy: pages load,
links resolve, and each page carries the SEO essentials (title, meta
description, viewport, exactly one H1). Works on JavaScript apps because the
check renders in a headless browser.

## Inputs

- `--url` — the page or site root to check (localhost during build, the live URL after deploy)
- `--max-pages` — crawl limit for same-origin links (default 25)
- `--expect-status` — for a single-URL health check (default 200)
- Optional `--report` — path for the Markdown report (default `qa_report_<host>.md`)

## Execution tools

1. `python executions/qa_website.py --url https://example.com --max-pages 25`
   - Requires Playwright once: `pip install playwright && playwright install chromium`
   - Prints one line per page with PASS/FAIL and the reasons; exit code 1 on any FAIL

## Outputs

- Console summary + `qa_report_<host>.md` (per-page title, description length,
  H1 count, viewport, broken links)
- Exit 0 = all pages pass; exit 1 = failures listed

## Edge cases & learnings
- **Every link "broken" but the pages load?** Suspect the checker's network path, not the site. Links are checked with fetch() inside the page (the browser's stack, which falls back IPv6 -> IPv4 like a visitor's); a side HTTP client that hangs on broken IPv6 once reported a healthy site as all-broken. Confirm with `curl -4` / `curl -6` before touching the site.

- **SPAs render after load** → the script waits for `networkidle` before reading
  the DOM; a static fetch would report a missing H1. Standard: QA JS apps only
  with a headless browser.
- **Caching after deploy** → run the check against the LIVE production URL after
  deploy, not just localhost; a CDN can serve the old HTML for minutes. If live
  fails but local passes, purge the cache and re-run before "fixing" code.
- **Meta description length** → 50–160 characters; outside that is a warning,
  not a failure, unless the page has none.
- **Multiple H1s** on a page is a FAIL (header hierarchy); zero H1s is a FAIL.
- **External links** are checked with a HEAD request and reported, but a slow
  third party is a warning, not a failure (don't block deploys on other people's uptime).
- **Fail-fast loop:** if any check fails, fix the underlying code, rebuild, and
  restart the whole check — don't accept a partial pass.

## Verification

The last line reads `QA: PASS (<n> pages)`.
