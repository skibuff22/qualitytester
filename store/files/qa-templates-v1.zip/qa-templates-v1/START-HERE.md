Fastener & Anchor Pull-Test Templates v1
Quality Tester Solutions LLC - https://calyx-ai.net/qa/

Files
- pull-test-report-template.xlsx  Proof Test report (auto PASS/FAIL, summary), Ultimate Load
                                  statistics (mean, s, CoV, mean - k*s), Calibration Log (due
                                  dates, OVERDUE flag), unit Converter, Standards Index.
                                  Works in Excel, LibreOffice Calc and Google Sheets.
- pull-test-report-template.pdf   Printable blank of the Proof Test sheet for field use.
- pull-test-procedure-checklist.pdf   Before / at each fastener / after checklist.
- standards-index.pdf             Which ASTM / ISO / ACI / ICC-ES / BS document covers what.

Yellow cells are inputs; white cells are formulas.

The templates record and summarise results. Acceptance criteria, load levels, sample
sizes and characteristic-value factors come from your specification, the anchor
manufacturer and the governing standard.

License: use and modify freely inside your organisation, including on client
reports. Do not resell or redistribute the templates themselves.
