# Directive: Publish verification

Give this file to your agent (Claude Code, Cursor, Codex) as the standing rule for
anything published under your name.

## Goal
Nothing goes out that is wrong, unverifiable, or reads like stock AI writing.

## Inputs
- A draft in `posts/<channel>-<slug>.md` with front matter: `channel`
  (hn|reddit|devto|linkedin|producthunt|x|other), `title`, `url` for link posts
  (with `utm_source=<channel>` on your own links), `rule:` (the community rule you
  relied on). Claims about third parties carry `[src: URL]` inline.
- `facts.md`: the only source of truth for claims and numbers.
- `voice.md`: how you write, plus banned phrases.

## Steps
1. Write the draft from `facts.md` only.
2. `python3 executions/verify_post.py posts/<file>` must print PASS. It writes
   `<file>.verified.json` (sha256 of the body). Edit the draft, re-run.
   `--no-llm` exists for tests; publishers refuse a sidecar made with it.
3. Read the target community's self-promotion rule in the same session and record
   it as `rule:`. If it forbids the post, do not post.
4. Publish only through `executions/post_<channel>.py`. Every publisher calls
   `require_verified()`, which refuses on a missing or stale sidecar.
5. Replies to comments are posts: same gate, `posts/reply-<slug>-<n>.md`.

## Hard rules
- One post per product per community. Never repost a removed post.
- Never fabricate testimonials, numbers, benchmarks, customers or history.
- No DMs, no cold outreach, no vote requests, no second accounts.
- If the LLM is unavailable, the gate fails and nothing posts.

## Edge cases
- The number check is strict on purpose: "saved 40 hours" with no evidence is a
  hallucination until proven. Put the evidence in `facts.md`, not in the post.
- A captcha or rate-limit notice means stop for the day; never retry in a loop.
- Scheduled runs (cron/systemd) often lack `~/.local/bin` on PATH; verify_post
  resolves `claude` there, or set `PUBLISH_GATE_LLM`.

## Verification
`pytest -q tests/` passes; every file in `posts/published/` has a matching
`.verified.json`.
