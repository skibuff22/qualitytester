#!/usr/bin/env python3
"""post_devto.py - example publisher behind the gate (dev.to Articles API).

    DEVTO_API_KEY=... python3 executions/post_devto.py posts/devto-my-article.md [--draft]

Copy this file to write publishers for other channels: load_post -> require_verified
-> post -> mark_published. Front matter used: title, tags (comma list), canonical_url.
"""
import json, sys, urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from publish_common import env, load_post, mark_published, require_verified  # noqa: E402


def main(argv):
    if len(argv) < 2:
        print(__doc__); return 2
    path = Path(argv[1])
    fm, body = load_post(path)
    side = require_verified(path, body)          # exits unless the gate passed on this exact body
    article = {"title": fm["title"], "body_markdown": body, "published": "--draft" not in argv}
    if fm.get("tags"):
        article["tags"] = [t.strip() for t in fm["tags"].split(",")][:4]
    if fm.get("canonical_url"):
        article["canonical_url"] = fm["canonical_url"]
    req = urllib.request.Request("https://dev.to/api/articles", method="POST",
                                 data=json.dumps({"article": article}).encode(),
                                 headers={"api-key": env("DEVTO_API_KEY"), "Content-Type": "application/json",
                                          "User-Agent": "publish-gate/1"})
    with urllib.request.urlopen(req, timeout=30) as r:
        url = json.load(r).get("url", "")
    mark_published(path, side, url, "devto")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
