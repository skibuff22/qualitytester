#!/usr/bin/env python3
"""verify_post.py - pre-publish gate for anything you post publicly.

Usage:
  python3 executions/verify_post.py posts/hn-my-launch.md [--no-llm] [--no-net]
                                    [--facts facts.md] [--voice voice.md]

Exit 0 = PASS (writes <post>.verified.json with a content hash your publishers check).
Exit 1 = FAIL (reasons printed; nothing written).

Checks (deterministic):
  1. front matter present: channel, title; url for channels that post a link
  2. banned phrases: built-in AI-slop list + "## Banned phrases" bullets in voice.md
  3. structure: no emoji, <=1 exclamation mark, em-dash density, no rhetorical openers
  4. every http(s) link resolves 2xx/3xx; links to CHECKOUT_MARKER carry utm_source
  5. every number in the body appears in facts.md (or the line carries [src: URL]);
     years, times, version strings and list numbering are exempt
Checks (LLM, default on):
  6. an LLM classifies each factual claim against facts.md:
     SUPPORTED / UNSUPPORTED / CONTRADICTED. Any UNSUPPORTED or CONTRADICTED -> FAIL.
     If the LLM is unavailable the gate FAILS (never publish unverified).
     Command: PUBLISH_GATE_LLM env var (prompt is passed on stdin), default `claude -p`.
"""
import hashlib, json, os, re, shlex, shutil, subprocess, sys, time, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FACTS = ROOT / "facts.md"
VOICE = ROOT / "voice.md"
LINK_CHANNELS = ("hn", "reddit", "producthunt", "lobsters")
CHECKOUT_MARKER = os.environ.get("PUBLISH_GATE_CHECKOUT_MARKER", "checkout")

BLACKLIST = [
    r"\bexcited\b", r"\bthrilled\b", r"\bpassionate\b", r"\brockstar\b", r"\bgame[- ]chang",
    r"\bsynergy\b", r"\bdelve\b", r"\btapestry\b", r"\bunlock\b", r"\belevate\b",
    r"\bseamless(ly)?\b", r"\brevolutioni[sz]e\b", r"\bharness the power\b", r"\bdive (in|into)\b",
    r"\bdeep dive\b", r"\blet'?s explore\b", r"\bcutting[- ]edge\b", r"\bever[- ]evolving\b",
    r"\btestament to\b", r"\bin today'?s (fast[- ]paced|digital|rapidly)", r"\bat the end of the day\b",
    r"\bit'?s worth noting\b", r"\bnavigat(e|ing) the (complex|landscape)", r"\blandscape\b",
    r"\bsupercharge\b", r"\bnext[- ]level\b", r"\bcrucial\b", r"\bparadigm\b", r"\bempower",
    r"\bjourney\b", r"\bunleash\b", r"\bgroundbreaking\b", r"\btransformative\b",
    r"\bI hope this (helps|finds)\b", r"\bwithout further ado\b", r"\bbuckle up\b",
    r"\bthe future of\b", r"\bmust[- ]have\b", r"\b10x\b",
]
RHETORICAL_OPENERS = [r"^\s*(ever wondered|have you ever|what if I told you|imagine (a|this))", r"\?\s*$"]
EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF☀-➿\U0001F900-\U0001F9FF]")
URL_RE = re.compile(r"https?://[^\s)>\]\"']+")
NUM_RE = re.compile(r"(?<![\w./-])\$?\d[\d,]*(?:\.\d+)?%?(?![\w./-])")
EXEMPT_NUM_CTX = re.compile(r"(\b(19|20)\d{2}\b|\d{1,2}:\d{2}|\bv?\d+\.\d+(\.\d+)?\b|^\s*\d+[.)]\s)")


def parse(path: Path):
    text = path.read_text(encoding="utf-8")
    fm, body = {}, text
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            for line in text[3:end].strip().splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    fm[k.strip()] = v.strip().strip('"')
            body = text[end + 4:].lstrip("\n")
    return fm, body


def facts_numbers():
    if not FACTS.exists():
        return set()
    return {m.group(0).replace(",", "").lstrip("$").rstrip("%") for m in NUM_RE.finditer(FACTS.read_text(encoding="utf-8"))}


def voice_banned():
    """Extra banned phrases: bullets under a '## Banned phrases' heading in voice.md."""
    if not VOICE.exists():
        return []
    out, inside = [], False
    for line in VOICE.read_text(encoding="utf-8").splitlines():
        if line.startswith("#"):
            inside = line.strip().lower().lstrip("#").strip() == "banned phrases"
            continue
        m = re.match(r"^\s*[-*]\s+(.+?)\s*$", line)
        if inside and m:
            out.append(r"\b" + re.escape(m.group(1).strip("`\"'").lower()) + r"\b")
    return out


def check_links(body, timeout=15):
    fails = []
    for url in sorted(set(URL_RE.findall(body))):
        u = url.rstrip(".,;:")
        if CHECKOUT_MARKER and CHECKOUT_MARKER in u and "utm_source=" not in u:
            fails.append(f"checkout link without utm_source: {u}")
        try:
            req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0 (verify_post)"}, method="GET")
            with urllib.request.urlopen(req, timeout=timeout) as r:
                if r.status >= 400:
                    fails.append(f"link {u} -> HTTP {r.status}")
        except Exception as e:  # noqa: BLE001
            fails.append(f"link {u} unreachable: {e}")
    return fails


def deterministic(fm, body, net=True):
    fails = []
    for k in ("channel", "title"):
        if not fm.get(k):
            fails.append(f"front matter missing: {k}")
    if fm.get("channel") in LINK_CHANNELS and not fm.get("url"):
        fails.append("front matter missing: url (link posts need one)")
    low = body.lower()
    for pat in BLACKLIST + voice_banned():
        for m in re.finditer(pat, low):
            fails.append(f"banned phrase: '{m.group(0)}'")
    if EMOJI_RE.search(body):
        fails.append("emoji present")
    if body.count("!") > 1:
        fails.append(f"{body.count('!')} exclamation marks (max 1)")
    words = max(1, len(body.split()))
    dashes = body.count("—") + body.count(" -- ")
    if dashes / words > 0.01:
        fails.append(f"em-dash density {dashes}/{words} words (max 1 per 100)")
    for i, line in enumerate(body.splitlines()[:3]):
        for pat in RHETORICAL_OPENERS:
            if re.search(pat, line.strip(), re.I):
                fails.append(f"rhetorical opener on line {i+1}: '{line.strip()[:60]}'")
    allowed = facts_numbers()
    for line in body.splitlines():
        if "[src:" in line:
            continue
        probe = EXEMPT_NUM_CTX.sub(" ", line)
        for m in NUM_RE.finditer(probe):
            n = m.group(0).replace(",", "").lstrip("$").rstrip("%")
            if n not in allowed:
                fails.append(f"number '{m.group(0)}' not in facts.md and no [src: ] on line: '{line.strip()[:70]}'")
    if net:
        fails += check_links(body)
    return fails


def llm_cmd():
    """PUBLISH_GATE_LLM wins; otherwise claude -p, resolved off PATH too (cron/systemd
    shells often lack ~/.local/bin)."""
    custom = os.environ.get("PUBLISH_GATE_LLM", "").strip()
    if custom:
        return shlex.split(custom)
    found = shutil.which("claude")
    if not found:
        for p in (Path.home() / ".local" / "bin" / "claude", Path("/usr/local/bin/claude")):
            if p.exists():
                found = str(p); break
    return [found or "claude", "-p", "--output-format", "text"]


def llm_check(fm, body):
    """Claim-by-claim check. Returns (fails, raw)."""
    facts = FACTS.read_text(encoding="utf-8") if FACTS.exists() else ""
    voice = VOICE.read_text(encoding="utf-8") if VOICE.exists() else ""
    prompt = f"""You are a fact-checker and editor. Do not rewrite. Judge only.

FACTS (the only source of truth; anything not here is unverified):
<facts>
{facts}
</facts>

VOICE GUIDE:
<voice>
{voice}
</voice>

POST (channel={fm.get('channel')}, title={fm.get('title')}):
<post>
{body}
</post>

Tasks:
1. List every factual claim in the post (product features, numbers, comparisons, history,
   what a tool does, what the author did). For each: SUPPORTED (stated in FACTS or a
   universally known fact), UNSUPPORTED (not in FACTS, cannot be verified), or CONTRADICTED.
   Opinions and plans are not claims. Claims about third parties need a [src: URL] in the post.
2. Say whether the post reads as written by a person following the voice guide, and list
   any sentence that reads as generic AI writing (filler, hype, hedging, throat-clearing).
Return ONLY JSON:
{{"claims":[{{"claim":"...","verdict":"SUPPORTED|UNSUPPORTED|CONTRADICTED","why":"..."}}],
 "voice_ok":true|false,"voice_issues":["..."]}}"""
    try:
        r = subprocess.run(llm_cmd(), input=prompt, capture_output=True, text=True, timeout=600)
        raw = r.stdout
        if r.returncode != 0:
            return [f"LLM check failed (exit {r.returncode}): {r.stderr.strip()[:200]}"], raw
    except Exception as e:  # noqa: BLE001
        return [f"LLM check unavailable: {e}"], ""
    m = re.search(r"\{.*\}", raw, re.S)
    if not m:
        return ["LLM check returned no JSON"], raw
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError as e:
        return [f"LLM JSON parse error: {e}"], raw
    fails = [f"claim {c.get('verdict')}: {c.get('claim')} ({c.get('why')})"
             for c in data.get("claims", []) if c.get("verdict") != "SUPPORTED"]
    if not data.get("voice_ok", False):
        fails += [f"voice: {s}" for s in data.get("voice_issues", [])] or ["voice: not ok"]
    return fails, raw


def _opt(argv, name):
    if name in argv:
        i = argv.index(name)
        if i + 1 < len(argv):
            return Path(argv[i + 1])
    return None


def main(argv):
    global FACTS, VOICE
    if len(argv) < 2 or argv[1].startswith("-"):
        print(__doc__); return 2
    FACTS = _opt(argv, "--facts") or FACTS
    VOICE = _opt(argv, "--voice") or VOICE
    path = Path(argv[1]); net = "--no-net" not in argv; llm = "--no-llm" not in argv
    fm, body = parse(path)
    fails = deterministic(fm, body, net=net)
    if llm and not fails:
        more, _ = llm_check(fm, body); fails += more
    if fails:
        print(f"FAIL {path}")
        for f in fails: print("  -", f)
        return 1
    digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
    side = path.with_suffix(path.suffix + ".verified.json")
    side.write_text(json.dumps({"sha256": digest, "verified_at": int(time.time()),
                                "net": net, "llm": llm, "channel": fm.get("channel")}, indent=1))
    print(f"PASS {path} sha256={digest[:12]} -> {side.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
