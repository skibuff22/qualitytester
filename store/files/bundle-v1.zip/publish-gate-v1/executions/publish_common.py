"""Shared helpers for your publishers (post_<channel>.py). Every publisher must call
require_verified() before it touches the network."""
import hashlib, json, os, shutil, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PUBLISHED = ROOT / "posts" / "published"


def load_post(path: Path):
    sys.path.insert(0, str(ROOT / "executions"))
    from verify_post import parse  # noqa: E402
    return parse(path)


def require_verified(path: Path, body: str):
    """Refuse unless <post>.verified.json exists, its sha256 matches the body, and the
    LLM check ran. Returns the sidecar path."""
    side = path.with_suffix(path.suffix + ".verified.json")
    if not side.exists():
        sys.exit(f"REFUSED: {side.name} missing - run executions/verify_post.py first")
    data = json.loads(side.read_text())
    digest = hashlib.sha256(body.encode("utf-8")).hexdigest()
    if data.get("sha256") != digest:
        sys.exit("REFUSED: post changed since verification - re-run verify_post.py")
    if not data.get("llm", False):
        sys.exit("REFUSED: verification ran with --no-llm; publishers need the full gate")
    return side


def env(name: str) -> str:
    v = os.environ.get(name, "")
    if not v:
        sys.exit(f"MISSING CREDENTIAL: {name} not set in the environment")
    return v


def mark_published(path: Path, side: Path, url: str, channel: str):
    """Move the post + sidecar to posts/published/ and append to log.jsonl."""
    PUBLISHED.mkdir(parents=True, exist_ok=True)
    shutil.move(str(path), PUBLISHED / path.name)
    shutil.move(str(side), PUBLISHED / side.name)
    with (PUBLISHED / "log.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps({"ts": int(time.time()), "channel": channel, "file": path.name, "url": url}) + "\n")
    print(f"PUBLISHED {channel}: {url}")
