# Voice guide

The LLM check reads this file and flags sentences that do not match it. The
"Banned phrases" list below is also enforced deterministically by verify_post.py.

## Who is speaking
- One named person, first person singular. Role and what they actually do.

## How they write
- Short declarative lead. Context, constraint, action, result.
- Concrete nouns and numbers from facts.md. No adjectives doing the work of evidence.
- Concede limits plainly ("it does not do X").
- No emoji, no hype, at most one exclamation mark.

## Never
- Claim to have done something you did not do.
- Ask for votes, stars or upvotes.

## Banned phrases
- world-class
- best-in-class
- low-hanging fruit
