"""Publish Gate tests: deterministic checks + publisher refusal. No network, no LLM."""
import json, sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "executions"))
import publish_common as pc  # noqa: E402
import verify_post as vp  # noqa: E402

CLEAN = """---
channel: hn
title: Show HN: A pre-publish gate for AI-assisted posts
url: https://example.com/?utm_source=hn
---
I write with an AI agent and check every draft against a facts file.
The gate has 3 layers. The kit is $19.
"""

SLOP = """---
channel: hn
title: Unlock the future
---
Ever wondered how to supercharge your workflow? I'm thrilled to share this game-changing
kit! It has 500 templates and saved me 40 hours!! Let's dive in.
"""


def post(tmp_path, text, name="p.md"):
    p = tmp_path / name
    p.write_text(text, encoding="utf-8")
    return p


@pytest.fixture(autouse=True)
def isolated(tmp_path, monkeypatch):
    monkeypatch.setattr(vp, "FACTS", tmp_path / "facts.md")
    monkeypatch.setattr(vp, "VOICE", tmp_path / "voice.md")
    (tmp_path / "facts.md").write_text("- layers: 3\n- price: $19\n")


def test_clean_passes(tmp_path):
    fm, body = vp.parse(post(tmp_path, CLEAN))
    assert vp.deterministic(fm, body, net=False) == []


def test_slop_fails(tmp_path):
    fm, body = vp.parse(post(tmp_path, SLOP))
    joined = "\n".join(vp.deterministic(fm, body, net=False))
    assert "missing: url" in joined
    assert "thrilled" in joined and "game-chang" in joined and "supercharge" in joined
    assert "exclamation" in joined and "rhetorical opener" in joined
    assert "number '500'" in joined and "number '40'" in joined


def test_numbers_with_source_are_exempt(tmp_path):
    fm, body = vp.parse(post(tmp_path, "---\nchannel: devto\ntitle: t\n---\nThe repo had 1,200 stars in 2025 [src: https://example.com]\n"))
    assert vp.deterministic(fm, body, net=False) == []


def test_voice_banned_phrases_enforced(tmp_path):
    (tmp_path / "voice.md").write_text("# Voice\n- not a ban\n## Banned phrases\n- world-class\n- `best-in-class`\n## Other\n- fine\n")
    fm, body = vp.parse(post(tmp_path, "---\nchannel: devto\ntitle: t\n---\nA world-class, best-in-class tool. Not a ban. Fine.\n"))
    fails = vp.deterministic(fm, body, net=False)
    assert any("world-class" in f for f in fails) and any("best-in-class" in f for f in fails)
    assert not any("not a ban" in f or "fine" in f for f in fails)


def test_checkout_link_needs_utm(tmp_path, monkeypatch):
    monkeypatch.setattr(vp.urllib.request, "urlopen", lambda *a, **k: (_ for _ in ()).throw(OSError("offline")))
    fm, body = vp.parse(post(tmp_path, "---\nchannel: devto\ntitle: t\n---\nBuy: https://shop.example.com/checkout?sku=A\n"))
    assert any("without utm_source" in f for f in vp.deterministic(fm, body, net=True))


def test_llm_unavailable_fails_closed(tmp_path, monkeypatch):
    monkeypatch.setenv("PUBLISH_GATE_LLM", str(tmp_path / "no-such-llm"))
    fails, _ = vp.llm_check({"channel": "devto", "title": "t"}, "body")
    assert fails and "unavailable" in fails[0]


def test_llm_verdicts_parsed(tmp_path, monkeypatch):
    fake = tmp_path / "fake_llm.sh"
    fake.write_text('#!/bin/sh\ncat >/dev/null\necho \'{"claims":[{"claim":"x","verdict":"UNSUPPORTED","why":"not in facts"}],"voice_ok":true}\'\n')
    fake.chmod(0o755)
    monkeypatch.setenv("PUBLISH_GATE_LLM", str(fake))
    fails, _ = vp.llm_check({"channel": "devto", "title": "t"}, "body")
    assert fails == ["claim UNSUPPORTED: x (not in facts)"]


def test_publisher_refuses_without_valid_sidecar(tmp_path):
    p = post(tmp_path, CLEAN)
    _, body = vp.parse(p)
    with pytest.raises(SystemExit, match="missing"):
        pc.require_verified(p, body)
    assert vp.main(["verify_post.py", str(p), "--no-net", "--no-llm"]) == 0
    with pytest.raises(SystemExit, match="no-llm"):
        pc.require_verified(p, body)
    side = p.with_suffix(".md.verified.json")
    data = json.loads(side.read_text()); data["llm"] = True; side.write_text(json.dumps(data))
    assert pc.require_verified(p, body) == side
    with pytest.raises(SystemExit, match="changed"):
        pc.require_verified(p, body + "edit")
