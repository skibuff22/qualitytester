# Facts (the only source of truth for anything you publish)

Every claim and every number in a post must appear here, or the line must carry
`[src: URL]`. If a reader proves a fact wrong, fix it here first.
Each fact gets evidence: a file path, a command and its output, or a URL.

## Company / author
- Name: Example Co. (evidence: state registry URL)
- Who builds the product, and with what (say if AI agents are involved).

## Product: <name>
- What it is, in one sentence.
- Price: $19 (evidence: checkout page URL)
- What is in it: 5 files (evidence: `unzip -l dist/product.zip`)
- What it does NOT do (write this down; it keeps posts honest).

## Numbers you may quote
- Tests: 6 passing (evidence: `pytest -q` output, date)

## Things never to claim
- Customer counts, testimonials or benchmarks you have not measured.
