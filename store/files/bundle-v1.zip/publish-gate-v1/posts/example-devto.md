---
channel: devto
title: Why every post I publish goes through a gate first
tags: writing, ai, automation
---
I publish with help from an AI agent, and I check every draft before it goes out.

The gate is a script. It rejects stock AI phrases, numbers that are not in my facts file,
and links that do not resolve. Then a model checks each claim against the same file.
If anything fails, nothing posts.

The product costs $19 and ships as 5 files plus tests.
