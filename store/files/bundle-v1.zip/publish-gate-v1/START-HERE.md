# Publish Gate v1: start here

A pre-publish gate for posts, articles and replies you write with an AI agent.
Nothing gets published unless the draft passes deterministic checks and an
LLM claim-by-claim check against your own facts file. Publishers refuse to post
a draft that changed after it passed.

## What is in the kit
| File | Purpose |
|---|---|
| `executions/verify_post.py` | The gate. PASS writes `<post>.verified.json` (sha256 of the body). |
| `executions/publish_common.py` | `require_verified()` and `mark_published()` for your publishers. |
| `executions/post_devto.py` | Example publisher (dev.to API). Copy it for other channels. |
| `facts.md` | Template: the only source of truth for claims and numbers. |
| `voice.md` | Template: your voice guide plus a "Banned phrases" list the gate enforces. |
| `directives/publish_verification.md` | The standing rule to give your coding agent. |
| `posts/example-devto.md` | A draft that passes against the template facts. |
| `tests/test_publish_gate.py` | 8 tests (no network, no LLM needed). |

## Setup (5 minutes)
1. Python 3.9+, no third-party packages. `pytest` only for the tests.
2. Copy the folder into your repo (or keep it standalone).
3. Fill in `facts.md` with evidence for every claim you want to be able to make.
4. Edit `voice.md`. Add your own banned phrases under "## Banned phrases".
5. LLM check: by default it runs `claude -p` (Claude Code). For another model, set
   `PUBLISH_GATE_LLM` to any command that reads the prompt on stdin and prints the
   answer, e.g. `PUBLISH_GATE_LLM="llm -m gpt-4o"`.

## Use
```
python3 executions/verify_post.py posts/example-devto.md            # full gate
python3 executions/verify_post.py posts/example-devto.md --no-net --no-llm   # quick lint
DEVTO_API_KEY=... python3 executions/post_devto.py posts/example-devto.md --draft
pytest -q tests/
```

## What the gate checks
1. Front matter: `channel`, `title`; `url` for link channels (hn, reddit, producthunt, lobsters).
2. Banned phrases: about 40 stock AI phrases plus your `voice.md` list.
3. Structure: no emoji, at most one `!`, em-dash density, no rhetorical openers.
4. Links resolve; checkout links (URL contains `checkout`, change with
   `PUBLISH_GATE_CHECKOUT_MARKER`) must carry `utm_source`.
5. Every number appears in `facts.md`, or the line has `[src: URL]`. Years, times,
   versions and list numbering are exempt.
6. LLM: every factual claim is SUPPORTED by `facts.md`; the text matches `voice.md`.
   If the LLM is unreachable the gate fails. It never passes unverified.

## What it does not do
- It does not write posts for you, and it does not guarantee a community will accept a post.
- It cannot catch a false fact you put in `facts.md` yourself.
- The LLM check is a second opinion, not proof; the deterministic checks are the floor.

## Support
Questions or a broken download: tdoane@calyx-ai.net (the contact on the storefront)
