#!/usr/bin/env python3
"""
guard_bash.py — Claude Code PreToolUse hook for the Bash tool.

Blocks (exit 2, reason on stderr, which Claude Code shows to the agent) when a
command would:
  1. commit while executions/lint_secrets.py finds a hard-coded credential
  2. skip git hooks (`git commit --no-verify`, `-n`)
  3. force-push (`--force`, `-f`, `+refspec`); `--force-with-lease` is allowed
  4. `rm -r` the filesystem root, the home directory, the project root, or `*`
  5. `pip install <package>` ad hoc instead of from a requirements/lock file
     (allowed: `-r <file>`, `-e .`, `.`, `pip install -U pip`; a package name
     beside `-r`/`-c`/`-e` is still blocked)

Anything else exits 0 (allowed). The hook never edits the command.

Wire it in `.claude/settings.json` (see hooks/settings.example.json):
    "PreToolUse": [{"matcher": "Bash", "hooks": [{"type": "command",
        "command": "python3 \"$CLAUDE_PROJECT_DIR\"/hooks/guard_bash.py"}]}]

Opt-outs, per project, as environment variables (set them in settings.json "env"):
    AOK_ALLOW_ADHOC_PIP=1   allow `pip install <package>`
Test: python3 executions/tests/test_guard_bash.py
"""
from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

SEPARATORS = re.compile(r"\s*(?:&&|\|\||;|\||\n)\s*")


def split_commands(command: str) -> list[list[str]]:
    """Split a shell line on && || ; | and newlines, then tokenize each part."""
    parts = []
    for chunk in SEPARATORS.split(command):
        if not chunk.strip():
            continue
        try:
            tokens = shlex.split(chunk)
        except ValueError:  # unbalanced quotes: fall back to whitespace
            tokens = chunk.split()
        # drop leading env assignments (FOO=1 git push ...) and sudo
        while tokens and (re.match(r"^[A-Za-z_][A-Za-z0-9_]*=", tokens[0]) or tokens[0] == "sudo"):
            tokens = tokens[1:]
        if tokens:
            parts.append(tokens)
    return parts


def git_subcommand(tokens: list[str]) -> tuple[str, list[str]]:
    """Return (subcommand, args) for a git call, skipping `-C dir` / `-c k=v` options."""
    if not tokens or Path(tokens[0]).name != "git":
        return "", []
    i = 1
    while i < len(tokens) and tokens[i].startswith("-"):
        i += 2 if tokens[i] in ("-C", "-c") else 1
    return (tokens[i], tokens[i + 1:]) if i < len(tokens) else ("", [])


def check_force_push(args: list[str]) -> str | None:
    for a in args:
        if a.startswith("--force-with-lease") or a.startswith("--force-if-includes"):
            continue
        if a == "--force" or (re.match(r"^-[a-zA-Z]+$", a) and "f" in a) or (a.startswith("+") and len(a) > 1):
            return ("force-push blocked: it can delete commits on the remote. Use "
                    "`git push --force-with-lease` after checking `git log origin/<branch>..`, or ask the human.")
    return None


def check_no_verify(args: list[str]) -> str | None:
    if "--no-verify" in args or any(re.match(r"^-[a-zA-Z]*n[a-zA-Z]*$", a) for a in args if not a.startswith("--")):
        return ("`git commit --no-verify` blocked: the pre-commit checks exist to stop this commit "
                "if it is broken. Fix what the hook reports instead of skipping it.")
    return None


def check_secrets(project: Path) -> str | None:
    linter = project / "executions" / "lint_secrets.py"
    if not linter.is_file():
        return None
    r = subprocess.run([sys.executable, str(linter), "--root", str(project), "--json"],
                       capture_output=True, text=True, timeout=120)
    if r.returncode == 0:
        return None
    try:
        data = json.loads(r.stdout)
        where = [f"{f['file']}:{f['line']} ({f['type']})" for f in data.get("findings", [])][:10]
        where += data.get("warnings", [])
    except (ValueError, KeyError):
        where = [r.stdout.strip()[:500] or r.stderr.strip()[:500]]
    return ("commit blocked: executions/lint_secrets.py found credentials or an un-ignored .env:\n  "
            + "\n  ".join(where) + "\nMove the value to .env (gitignored) and read it from the environment.")


DANGEROUS_RM_TARGETS = {"/", "/*", "~", "~/", "~/*", "$HOME", "$HOME/", "${HOME}", "*", ".", "./", "..", "../"}


def check_rm(tokens: list[str], project: Path) -> str | None:
    if Path(tokens[0]).name != "rm":
        return None
    flags = "".join(t.lstrip("-") for t in tokens[1:] if t.startswith("-") and not t.startswith("--"))
    recursive = "r" in flags.lower() or "--recursive" in tokens
    if not recursive:
        return None
    home = str(Path.home())
    for t in tokens[1:]:
        if t.startswith("-"):
            continue
        norm = t.rstrip("/") or "/"
        if t in DANGEROUS_RM_TARGETS or norm in {home, str(project), "/"}:
            return (f"`rm -r {t}` blocked: that removes the filesystem root, your home directory or the "
                    "whole project. Name the exact directory to delete.")
    return None


# `pip install` options that take a value. The value is consumed with the flag, so
# `-r requirements.txt requests` still leaves `requests` to check (v1.1.0 waived the
# whole line once -r/-c/-e appeared). `-e <path>` is the exception: its value is an
# install source, so it is checked like a positional argument.
PIP_VALUE_FLAGS = {
    "-r", "--requirement", "-c", "--constraint", "-i", "--index-url", "--extra-index-url",
    "-f", "--find-links", "-t", "--target", "--prefix", "--root", "--src", "--python",
    "--platform", "--python-version", "--implementation", "--abi", "--only-binary",
    "--no-binary", "--upgrade-strategy", "--progress-bar", "--log", "--cache-dir",
    "--trusted-host", "--proxy", "--timeout", "--retries", "--exists-action", "-C",
    "--config-settings", "--global-option", "--report", "--keyring-provider", "--group",
}
PIP_SELF = {"pip", "setuptools", "wheel"}  # `python -m pip install -U pip` is pip's own advice


def pip_install_targets(args: list[str]) -> list[str]:
    """Return what `pip install <args>` would install by name, after removing options and their values."""
    targets, i = [], 0
    while i < len(args):
        a = args[i]
        if a in ("-e", "--editable"):
            targets += args[i + 1:i + 2]
            i += 2
        elif a.startswith("--editable="):
            targets.append(a.split("=", 1)[1])
            i += 1
        elif a in PIP_VALUE_FLAGS:
            i += 2
        elif a.startswith("-"):
            i += 1  # boolean flag, `--opt=value`, or `-rfile`
        else:
            targets.append(a)
            i += 1
    return targets


def check_pip(tokens: list[str]) -> str | None:
    name = Path(tokens[0]).name
    if re.match(r"^python[0-9.]*$|^py$", name) and tokens[1:3] == ["-m", "pip"]:
        args = tokens[3:]
    elif re.match(r"^pip[0-9.]*$", name):
        args = tokens[1:]
    else:
        return None
    if not args or args[0] != "install" or os.environ.get("AOK_ALLOW_ADHOC_PIP") == "1":
        return None
    targets = pip_install_targets(args[1:])
    pkgs = [t for t in targets if t not in PIP_SELF and not t.startswith((".", "/"))]
    if not pkgs:
        return None
    return (f"ad-hoc `pip install {' '.join(pkgs)}` blocked: the package would be missing from the "
            "requirements file, so the next machine (CI, prod) breaks. Add it to requirements.txt "
            "(or pyproject.toml) with a version pin, then `pip install -r requirements.txt`. "
            "Set AOK_ALLOW_ADHOC_PIP=1 to allow this per project.")


def evaluate(command: str, project: Path) -> str | None:
    """Return the block reason for a Bash command, or None if it may run."""
    for tokens in split_commands(command):
        sub, args = git_subcommand(tokens)
        if sub == "push":
            reason = check_force_push(args)
        elif sub == "commit":
            reason = check_no_verify(args) or check_secrets(project)
        else:
            reason = check_rm(tokens, project) or check_pip(tokens)
        if reason:
            return reason
    return None


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except ValueError:
        return 0  # not a hook payload; never block on our own parse error
    if event.get("tool_name") != "Bash":
        return 0
    command = (event.get("tool_input") or {}).get("command", "")
    project = Path(os.environ.get("CLAUDE_PROJECT_DIR") or event.get("cwd") or ".").resolve()
    reason = evaluate(command, project)
    if reason:
        print(f"[guard_bash] {reason}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
