# Why D.O.E. works

## The arithmetic

An agent that is 90 % reliable per step is 59 % reliable over five steps
(0.9⁵). Over ten steps, 35 %. Real tasks are ten to fifty steps. If the agent
*executes* every step itself — fetching, parsing, transforming, writing — the
compounding kills you, and you end up babysitting.

Move the steps that have a right answer into code. A script that fetches, parses
and writes is ~100 % reliable once it works, and it stays that way. Now the
agent makes three decisions (which directive, which inputs, did it work) instead
of fifty executions. 0.9³ is 73 %, and the decisions are the part a model is
good at.

## The three layers, again

| Layer | Nature | Lives in | Who changes it |
|---|---|---|---|
| Directive | Intent, in prose | `directives/*.md` | Humans write; agents append learnings |
| Orchestration | Judgment | The agent (CLAUDE.md is its job description) | Prompt/tool vendor |
| Execution | Determinism | `executions/*.py` | Agents write, tests guard |

The boundary is the point. A directive never contains code; a script never
contains policy ("ask the user if…"); the agent never contains either — it reads
one and runs the other.

## What compounds

- **Directives accumulate edge cases.** Every API limit, timing quirk and
  platform gotcha the agent meets is written down where the *next* session will
  read it before acting. Month three is dramatically better than week one.
- **Scripts accumulate tests.** Every bug becomes a test. The surface that can
  regress shrinks.
- **Standards accumulate lints.** Every pattern-bug becomes a mechanical check.
  Whole classes of mistakes stop being possible.

That is what "self-annealing" means: the system gets stronger from each failure
instead of accumulating patches.

## What it costs

- Writing the first directive for a job takes longer than just asking the agent
  to do it. The second run is where you win.
- You have to hold the line on "recovery is not a fix". The pressure to just
  reprocess the stuck items is real. The loop in
  `directives/core/self-annealing-loop.md` exists to make that line easy to hold.

## Where it came from

Built to run a real small-business platform (CRM, invoicing, inventory,
calibration records, a hardware product line) with a fleet of agents — PM,
dev-lead, researcher, copywriter — coordinating in a shared workspace with
humans. The governance rules in `directives/core/agent-governance.md` are
post-mortems: each one is an incident that happened (an overnight audit spiral,
a key rotated by a deploy, a duplicate researcher) turned into a rule.
