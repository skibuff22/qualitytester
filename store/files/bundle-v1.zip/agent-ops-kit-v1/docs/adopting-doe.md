# Adopting D.O.E. in an existing codebase

You don't rewrite anything. You add three folders and one file, then migrate
one job at a time.

## Day 1 (30 minutes)

1. Drop in `CLAUDE.md`, `directives/`, `executions/`, `skills/`. Merge with an
   existing CLAUDE.md if you have one — keep yours, add the *Operating
   principles*, *Self-annealing loop* and *Mandatory directive checks* sections.
2. `py executions/lint_secrets.py` — fix anything it finds *today*. Rotate any
   leaked key; a key in git history is leaked even after you delete the line.
3. Add `.env` to `.gitignore`; move keys there.
4. Add the pre-commit hook from `executions/README.md`.

## Week 1 — migrate the job you do most

Pick the task you ask the agent to do most often (deploy, run the QA, pull a
report). Write its directive from `00_template.md`. If a script already exists,
reference it; if the agent has been doing it by hand, write the script from
`00_template.py` — the agent can draft it, you review.

From then on: "read CLAUDE.md, then <job>". Watch what it appends to the
directive's *Edge cases & learnings*. That section is your return on investment.

## Month 1 — the loop becomes habit

- Every bug: `anneal.py` entry + test + (if pattern) standard + lint.
- Every new script: referenced by a directive (the lint enforces it).
- Core directives synced into every repo you run; a 10-line sync script is enough:

```python
# executions/sync_core.py — copy canonical core/ into each project
import shutil, sys, pathlib
src = pathlib.Path("directives/core")
for repo in sys.argv[1:]:
    dst = pathlib.Path(repo) / "directives" / "core"
    shutil.copytree(src, dst, dirs_exist_ok=True)
    print("synced", dst)
```

## project-tracker.json (used by the project-status skill)

```json
{
  "project": "my-app",
  "phase": "MVP",
  "stories": [
    {
      "id": "APP-12",
      "title": "Stripe webhook records orders",
      "status": "in_progress",
      "owner": "dev-lead",
      "priority": 1,
      "depends_on": ["APP-10"],
      "definition_of_done": "webhook test passes; order row visible; directive updated",
      "blocker": null
    },
    {
      "id": "APP-13",
      "title": "Nightly backup restore drill",
      "status": "blocked",
      "owner": "dev-lead",
      "priority": 2,
      "depends_on": [],
      "definition_of_done": "restore from last night's backup boots and passes QA",
      "blocker": {"owner": "todd", "anticipated_resolution": "grant S3 read key", "eta": "2026-10-20"}
    }
  ]
}
```

## Signs it's working

- The agent's first action on a task is reading a directive, not guessing.
- Bug reports in your tracker link to a test and a directive line.
- You stop re-explaining the same gotcha ("use `py` on Windows") every session.
- Deploys are boring.
