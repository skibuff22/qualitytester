# Running a fleet of agents (without burning a fortune)

Once one agent works, the temptation is five. Here is the shape that held up in
production, and the three incidents that produced each rule.

## Topology

```
owner ──► pm ──► dev-lead     (code, tests, approved deploys)
             ├─► research     (the ONLY researcher; writes to the knowledge vault)
             ├─► qa           (runs qa_website.py; reports, never fixes code itself)
             └─► copywriter / graphics / …  (one agent per capability)
```

- Workers accept prompts only from the owner and `pm`. Everything else is
  dropped at the harness, which is what makes an idle fleet cost nothing.
- One shared workspace (a chat tool with channels, one channel per topic, one
  responder per channel). Humans and agents in the same channels — that's the
  point; a fleet you can't watch is a fleet you can't trust.
- Each agent has its own clone of each repo it works in, with a per-repo deploy
  key — never an account-level token. Revoking an agent is deleting one key.

## The incidents behind the rules

1. **The overnight audit spiral.** Two agents began verifying each other's
   record-keeping. By morning: hours of tokens, zero product output. Rule: the
   meta-work cap (one post per agent, three per thread, never ahead of product
   work, PM closes the thread with one issue).
2. **The rotated webhook key.** A redeploy rotated a webhook key; deliveries
   returned 401; the "fix" proposed was an hourly reprocess. Rule: repair before
   recovery, and deploy scripts own every side-effect of deploying.
3. **The second researcher.** Two agents each spun up a research helper for the
   same vendor question. Rule: one agent per capability; the PM is the registrar;
   `agents/registry.json` is the truth.

## Token discipline

- Idle = free. Gate at the harness, not with good intentions.
- Assign tasks with a definition of done. "Look into X" is an open tab on your
  credit card.
- Skills over prompts: anything you explain twice becomes a SKILL.md that calls a
  script. The script does the work; the skill is ten lines.
- Local models for high-volume low-stakes steps (classification, lead scoring,
  summarizing a channel); frontier models for judgment. Route by directive.

## Production safety

- No agent deploys without a standalone, per-request approval from the owner.
- The deploy agent holds the only prod key, and the key is per-agent.
- Live verification after every deploy (`qa_website.py` against the real URL),
  posted on the approval thread. "Deployed" means "verified live", nothing less.

## What to automate first

Marketing and ops before product: lead scoring, outreach drafts for human
approval, weekly status, QA on every deploy. They're bounded, measurable, and
they free the humans to make product decisions — which is the one job you
can't hand over.
