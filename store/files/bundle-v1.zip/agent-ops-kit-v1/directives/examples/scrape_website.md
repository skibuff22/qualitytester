# Directive: Scrape a website into structured data

## Goal

Turn a list of URLs into clean, deduplicated rows (CSV/JSON) without the agent
reading pages by hand. The agent decides *which* URLs and *which* fields; the
script fetches, parses, retries and writes.

## Inputs

- `--urls` — file with one URL per line (agent builds this from the user's request)
- `--fields` — CSS selectors or JSON-path per output column, e.g. `title=h1,price=.price`
- `--out` — output path (`.csv` or `.json`)
- `--delay` — seconds between requests (default 1.5; respect robots.txt and terms of use)

## Execution tools

1. `python executions/scrape_website.py --urls urls.txt --fields "title=h1,price=.price" --out data.csv`
   (Write it from `executions/00_template.py`: requests + BeautifulSoup for static
   pages; Playwright for JS pages — the QA script shows the Playwright pattern.)

## Outputs

- `data.csv` / `data.json` with one row per URL plus `fetched_at` and `status`
- `logs/scrape-<timestamp>.log` with per-URL status and retries

## Edge cases & learnings

- **403/429** → back off exponentially (2s, 4s, 8s, max 3 tries), then record
  the URL as `blocked` — never hammer. If a site forbids scraping in its terms
  or robots.txt, stop and tell the user; find an API or licensed data instead.
- **Selector returns nothing** on >20 % of pages → the markup changed; the
  script exits 3 with the first failing URL so the agent can inspect ONE page
  and update the selector — not re-scrape blindly.
- **Encoding** → always decode with the response's declared charset, fall back
  to UTF-8; write CSV with `utf-8-sig` so Excel opens it correctly.
- **Duplicates** → dedupe on normalized URL (strip tracking params, trailing slash).
- Personal data: collect only what the task needs; don't store emails/phones
  unless the user has a lawful basis and asked for them explicitly.

## Verification

Row count equals unique URL count; `status` column has no `error` rows (blocked
rows are acceptable and reported).
