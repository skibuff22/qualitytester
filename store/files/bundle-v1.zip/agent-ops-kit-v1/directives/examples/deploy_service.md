# Directive: Deploy a service to a remote host

## Goal

Ship a tested change from this repo to a production host over SSH with a
repeatable script, verify it live, and record the deploy. Use this for any
"deploy", "push to prod", "update on the server", "restart the service" request.

## Inputs

- `DEPLOY_HOST`, `DEPLOY_USER`, `DEPLOY_KEY_PATH` — from `.env` (never in chat)
- `--paths` — files/dirs to ship (relative to repo root). Default: `app/`
- `--service` — systemd/launchd unit to restart after copy (optional)
- Current commit hash (`git rev-parse --short HEAD`) — must be committed; the script refuses a dirty tree

## Execution tools

1. `python executions/lint_secrets.py` — must pass before anything leaves the machine
2. `python executions/deploy_service.py --paths app/ --service myapp` — copies raw
   bytes with scp, strips BOM/CRLF on text files, restarts the unit, prints the
   deployed commit hash. (Write this script from `executions/00_template.py`
   for your host; the kit ships the shape, not your credentials.)
3. `python executions/qa_website.py --url https://your-host/health --expect-status 200`
   — live verification; a deploy is not done until this prints PASS

## Outputs

- Files on the host updated; service restarted
- `logs/deploy-<timestamp>.json` with commit, files, host, verification result
- A one-line note in the tracker/changelog with the commit hash

## Edge cases & learnings

- Dirty working tree → script exits 2. Commit first; never deploy uncommitted code.
- Windows-authored files carry CRLF/BOM that break shell scripts and Python on
  Linux hosts → the deploy script normalizes them; standard: never copy text
  files with a tool that may transcode.
- Service restart succeeds but the old process still owns the port → verification
  catches it (health returns stale version); fix the unit's `KillMode`, don't
  "restart twice".
- API-version vs model-version confusion (an LLM endpoint 404s after deploy) →
  the env var names in `.env` must match the names the config module reads;
  add a lint comparing the two (`lint_env_names.py` — pattern from
  `lint_directives.py`).
- Production deploys need owner approval per request — see
  `directives/core/agent-governance.md`.

## Verification

`python executions/qa_website.py --url <health url>` prints `PASS`, and the
health payload shows the new commit hash.
