# directives/

Standard operating procedures the agent reads *before* acting in an area.

- `core/` — project-independent rules. Sync these unchanged into every repo you run
  (a one-line script that copies `core/` is enough; keep the canonical copy in one
  place and mark synced copies "do not edit here").
- `examples/` — complete, real-shaped directives. Copy one when you write your own.
- `00_template.md` — the required section layout.

Rules of the folder:

1. One directive per job. Name it after the job (`deploy_api.md`, not `misc.md`).
2. Every execution script referenced must exist; every script in `executions/`
   must be referenced by at least one directive. `executions/lint_directives.py`
   enforces both.
3. Learnings go in the *Edge cases & learnings* section in the same session they
   are learned, dated, with the root cause and the test that covers it.
4. The agent proposes directive edits; a human (or the PM agent) reviews before
   a directive is deleted or rewritten wholesale. Appending learnings needs no review.
