# Core Directive: Agent Governance

> CORE FILE — sync unchanged into every project. Applies the moment you run more
> than one persistent agent (or one agent that can spawn others).

## Work authorization (who may spend tokens)

An agent works ONLY on tasks authorized by the owner or by its project-manager
(PM) agent, and works until those tasks are finished — then it goes quiet.

1. **Gate at the harness:** worker agents accept prompts only from the owner and
   their PM; PM agents accept only the owner. Unauthorized prompts are dropped
   silently and cost nothing. An idle agent consumes no tokens.
2. **Discipline:** the PM assigns work as explicit tasks with a definition of
   done. An agent finishing its list posts a short completion note and stops —
   no self-invented follow-on work without new authorization.
3. The owner can always stop an agent hard (cancel the turn, shut the harness
   down, stop the service).

## One agent per capability — the PM is the registrar

Before creating or starting ANY persistent agent or subagent:

1. Check `agents/registry.json` — the authoritative list of agents, what they
   do, and how to reach them.
2. Ask the PM: "does X exist / may I use it?" The PM points you at the existing
   agent or approves a new one.
3. A new agent comes to life only through the PM: definition file + registry
   entry committed FIRST, then provisioning. An agent not in the registry
   shouldn't exist.

Throwaway in-session helpers (a tool's own one-turn subagents) need no
registration — the registry governs persistent agents with identities.

## Research goes through one researcher

Any agent needing research (vendors, standards, datasheets, market data) routes
the request via its PM to the research agent, and checks the shared knowledge
vault FIRST — the answer may already be there. Never spin up a second researcher.

## Meta-work cap (introspection threads)

Meta-work = discussion of the agents' own processes: audits of each other's
records, verifying past statements, process post-mortems, tooling-about-tooling.
Unbounded, it burns hours of tokens with zero product output.

1. **One post per agent per meta thread.** State the finding, the fix, and the
   issue/commit carrying it — then stop.
2. **Three posts total, thread-wide.** At the third post the thread closes;
   whatever remains becomes ONE issue the PM prioritizes like any other work.
3. **Never ahead of product work.** No meta-work while a critical issue is open
   or an assigned task is unfinished.
4. **PMs enforce.** Agents comply without argument in-channel.

Process defects found during meta-work are real and welcome — the cap is on
*discussion*, not on *fixing*.

## Production deploys — approval-gated

1. Every production deploy needs the owner's explicit approval, per request. No
   standing approvals, no "same as last time".
2. The request is a STANDALONE message that mentions the owner, stating: what
   (files + commit hash), why, risk, rollback plan, post-deploy verification.
3. No push until the owner approves THAT request. Silence is not approval. An
   amended deploy (even one file) is a new request.
4. Only the designated deploy agent holds a prod key; keys are per-agent and
   revocable. PMs prepare and review requests but hold no keys.
5. After deploying, run the live verification named in the deploy directive and
   post the result on the same request thread.
