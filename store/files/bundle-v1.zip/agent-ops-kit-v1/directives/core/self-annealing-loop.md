# Core Directive: The Self-Annealing Loop

> CORE FILE — sync unchanged into every project.

Errors are learning opportunities. Every failure runs this loop, in this order.
The four-part shape is **Root Cause → Fix → Test → Standard**; recovery is the
LAST step, never the first.

## The loop

1. **Diagnose the root cause.** Ask "why did this happen?" until you reach a
   cause that, once fixed, prevents recurrence. Saying "just retry it" or "reset
   and rerun" means you haven't found it.
2. **Fix the root cause** in code, configuration, or infrastructure. If the fix
   is "add a manual step to a runbook", ask whether that step can be automated
   into the build/deploy pipeline instead.
3. **Update the tool.** If the fix changes how a script works, change the script.
4. **Write or update the test that would have caught it.** The test verifies the
   root cause is resolved, not merely that the symptom is gone.
5. **Create or update a coding standard** if the bug is a pattern (naming
   convention, API constraint, platform gotcha). The standard goes in the
   relevant directive AND in CLAUDE.md's mandatory-checks table.
6. **Create or update a lint/validation script** if the pattern is mechanically
   detectable. Put it in `executions/` and wire it into pre-commit/pre-deploy.
7. **Run the tool AND the tests** until all pass.
8. **Update the directive** with: failure mode, root cause, fix, test, standard.
   Record it: `python executions/anneal.py --failure "..." --root-cause "..." --fix "..." --test "..." --standard "..."`
9. **THEN recover** — reprocess stuck data, clear bad state, restart services.
10. The system is now stronger.

## Worked example

Blob-trigger stops firing on a document pipeline.

- ✗ Symptom fix: admin-reprocess the stuck documents every hour.
- ✓ Loop: investigate subscription health → find the webhook key rotated when the
  function app was redeployed (deliveries now 401) → add key refresh to the
  deploy script (fix) → test that a deploy leaves the subscription healthy
  (test) → directive gains "deploy rotates the webhook key; the deploy script
  refreshes it" (standard) → reprocess the stuck docs (recovery).

## Anti-patterns (each one is a loop skipped)

- "Let's just reprocess the stuck items" → recovery, not a fix. What made them stuck?
- "I'll add a cron to retry failed items" → band-aid. Why are they failing?
- "Reset the status and it should work" → hides the failure. What broke the transition?
- "It works if you redeploy" → workaround. Why does deployment break it?

## When the root cause can't be found

Say so explicitly. State the diagnostic evidence needed (logs, a reproduction,
a config dump) and how to get it. Do not apply a speculative fix — it masks the
signal the next investigator needs.
