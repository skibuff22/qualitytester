# Core Directive: Bug-Fix Standard

> CORE FILE — sync unchanged into every project.

A bug fix is complete only when all four parts exist. Reviewers (human or PM
agent) reject a fix missing any of them.

| Part | Required artifact | Where |
|---|---|---|
| Root cause | One sentence naming the mechanism ("the API version string was the *model* version, not the REST version, so every call 404'd") | PR/commit message + directive |
| Fix | The code/config/infra change | The change itself |
| Test | A test that fails before the fix and passes after | `executions/tests/` (unit preferred; integration if needed) |
| Standard | If the bug is a pattern: directive rule + lint in `executions/` when detectable | `directives/<area>.md`, CLAUDE.md table, `executions/lint_*.py` |

## The pattern question

After every fix ask: *could this same mistake be made somewhere else?*

- Field naming conventions (camelCase vs snake_case at a DB boundary) → yes → lint.
- Env var names that must match a config module → yes → lint that compares them.
- API version vs model version confusion → yes → directive rule + a test on the client.
- A typo in one string → no → test only.

## Commit message shape

```
fix(<area>): <symptom in user terms>

Root cause: <mechanism>
Fix: <what changed>
Test: executions/tests/<file>::<name>
Standard: directives/<file>.md "<rule title>" [+ executions/lint_<x>.py]
```

## Recovery, labelled

If recovery actions follow (reprocess, cleanup, restart), list them under a
heading **Recovery (after fix deployed)** so nobody mistakes them for the fix.
