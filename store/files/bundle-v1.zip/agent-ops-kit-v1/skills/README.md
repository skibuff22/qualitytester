# skills/

Claude Code skills that wrap the execution scripts. Install by copying each folder to
`.claude/skills/<name>/` in your repo (project skills) or `~/.claude/skills/` (personal).
Each SKILL.md is deliberately short: it tells the agent *which script to run and how to
read the result*, so the expensive reasoning happens once (here) instead of every session.

| Skill | Trigger | Runs |
|---|---|---|
| `qa-test` | "QA", "test the site", "post-deploy check", after every deploy | `executions/qa_website.py` |
| `deploy` | "deploy", "push to prod", "restart the service" | `lint_secrets.py` → `deploy_service.py` → `qa_website.py` |
| `project-status` | session start, "status", "what's next" | reads `project-tracker.json` |

Other agent tools: Cursor users put the SKILL.md body into `.cursor/rules/<name>.mdc`;
Codex/Gemini CLI users paste it into AGENTS.md / GEMINI.md under a heading.
