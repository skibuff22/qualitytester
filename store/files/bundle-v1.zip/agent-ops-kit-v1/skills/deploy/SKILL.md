---
name: deploy
description: Ship committed code to a server over SSH with the deploy script, then verify live. Triggers - "deploy", "push to prod", "update on the server", "restart the service", "go live".
---

# Deploy

Production deploys are approval-gated (`directives/core/agent-governance.md`): post a
standalone request naming files + commit hash, risk, rollback, verification — and wait
for explicit approval. Then:

1. Read `directives/examples/deploy_service.md`.
2. `py executions/lint_secrets.py` — must PASS.
3. Confirm the tree is clean (`git status --porcelain` empty) and the commit is pushed.
4. `py executions/deploy_service.py --paths <paths> --service <unit>` — note the commit hash it prints.
5. `py executions/qa_website.py --url <live health or home URL> --max-pages 5` — not done until `QA: PASS`.
6. Post the verification result on the approval thread; add a changelog/tracker line with the commit hash.
7. Anything surprising → `py executions/anneal.py ...` and append to the directive.
