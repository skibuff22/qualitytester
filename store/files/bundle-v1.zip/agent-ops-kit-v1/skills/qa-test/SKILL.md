---
name: qa-test
description: Headless-browser QA and SEO check of a site (links, title, meta description, viewport, single H1). MANDATORY after every build or deploy. Triggers - "QA", "test the site", "check the site", "smoke test", "post-deploy check", "does the site work".
---

# QA Test

1. Read `directives/examples/qa_website.md` (edge cases: SPA rendering, CDN caching, H1 rules).
2. Decide the URL: `http://localhost:<port>` during a build; the LIVE production URL after a deploy (both, if you just deployed).
3. Run: `py executions/qa_website.py --url <url> --max-pages 25` (first time: `pip install playwright && playwright install chromium`).
4. Read the last line. `QA: PASS` → report page count and any warnings. `QA: FAIL` → open the report, fix the underlying code (not the test), rebuild, and re-run the whole check from step 3. Do not accept a partial pass.
5. If live fails but local passes: purge the CDN/host cache, wait 60 s, re-run before changing code.
6. Record any new failure mode in the directive's *Edge cases & learnings* section.
