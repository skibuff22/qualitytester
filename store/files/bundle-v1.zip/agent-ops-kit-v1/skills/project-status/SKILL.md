---
name: project-status
description: Report current phase, progress, blockers and the recommended next stories from project-tracker.json. Use at the START of every session and on "status", "continue", "what's next", "pick up where we left off".
---

# Project Status

1. Read `project-tracker.json` at the repo root (schema in `docs/adopting-doe.md`). If it doesn't exist, offer to create one from the template there.
2. Report, in this order and nothing else:
   - **Phase** and % of stories done (done / total)
   - **In progress** stories with owner
   - **Blockers** — each must show owner, anticipated resolution, ETA; a blocker missing any field is itself a finding to report
   - **Recommended next 1–3 stories** (highest priority, unblocked, dependencies done)
3. If the tracker and reality disagree (a story marked done has no commit, a file it names doesn't exist), say so — reality wins — and offer to correct the tracker.
4. Keep it under 15 lines. The user asked for status, not a narrative.
