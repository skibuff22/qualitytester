# Changelog

## v1.0 — 2026-10-16

- Initial release: CLAUDE.md, 4 core directives, 3 example directives, 7 execution
  scripts (template, 2 linters, anneal log, QA, deploy, scrape), tests, 3 skills,
  PM/worker agent templates, registry schema, 3 docs.

Buyers get updates by email at no charge.
