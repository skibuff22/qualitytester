#!/usr/bin/env python3
"""
lint_directives.py — keep Layer 1 and Layer 3 in sync.

Checks (exit 1 on any error):
  1. every directives/**/*.md (except README/template) has the required sections
  2. every `executions/<name>.py` mentioned in a directive or CLAUDE.md exists
  3. every executions/*.py (except templates, lint_*, tests) is referenced by at least one directive
  4. every `directives/...md` path in CLAUDE.md's mandatory-checks table exists

Usage: py executions/lint_directives.py [--root .] [--json]
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

REQUIRED_SECTIONS = ["## Goal", "## Inputs", "## Execution tools", "## Outputs", "## Edge cases", "## Verification"]
SKIP_DIRECTIVE_NAMES = {"README.md", "00_template.md"}
SCRIPT_REF = re.compile(r"executions/([A-Za-z0-9_\-]+\.py)")
DIRECTIVE_REF = re.compile(r"directives/([A-Za-z0-9_\-/]+\.md)")


def lint(root: Path) -> dict:
    errors: list[str] = []
    warnings: list[str] = []
    ddir, edir = root / "directives", root / "executions"
    directives = [p for p in ddir.rglob("*.md") if p.name not in SKIP_DIRECTIVE_NAMES] if ddir.is_dir() else []
    if not directives:
        errors.append("no directives found under directives/")

    referenced_scripts: set[str] = set()
    for d in directives:
        text = d.read_text(encoding="utf-8", errors="replace")
        rel = d.relative_to(root).as_posix()
        if "/core/" not in rel:  # core directives are prose rules, not job SOPs
            for sec in REQUIRED_SECTIONS:
                if not re.search(rf"^{re.escape(sec)}", text, re.M):
                    errors.append(f"{rel}: missing section '{sec}'")
        for m in SCRIPT_REF.finditer(text):
            referenced_scripts.add(m.group(1))
            if not (edir / m.group(1)).is_file():
                errors.append(f"{rel}: references executions/{m.group(1)} which does not exist")

    claude = root / "CLAUDE.md"
    if claude.is_file():
        ctext = claude.read_text(encoding="utf-8", errors="replace")
        for m in DIRECTIVE_REF.finditer(ctext):
            if not (ddir / m.group(1)).is_file():
                errors.append(f"CLAUDE.md: references directives/{m.group(1)} which does not exist")
        for m in SCRIPT_REF.finditer(ctext):
            referenced_scripts.add(m.group(1))
            if not (edir / m.group(1)).is_file():
                errors.append(f"CLAUDE.md: references executions/{m.group(1)} which does not exist")
    else:
        warnings.append("no CLAUDE.md at repo root")

    if edir.is_dir():
        for s in sorted(edir.glob("*.py")):
            if s.name.startswith(("00_", "lint_", "test_")) or s.name == "anneal.py":
                continue
            if s.name not in referenced_scripts:
                errors.append(f"executions/{s.name}: not referenced by any directive (orphan tool)")

    return {"ok": not errors, "errors": errors, "warnings": warnings,
            "directives": len(directives), "scripts_referenced": sorted(referenced_scripts)}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Lint directives <-> executions consistency")
    ap.add_argument("--root", default=".")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    r = lint(Path(a.root).resolve())
    if a.json:
        print(json.dumps(r, indent=2))
    else:
        for w in r["warnings"]:
            print(f"warn  {w}")
        for e in r["errors"]:
            print(f"ERROR {e}")
        print(f"lint_directives: {'PASS' if r['ok'] else 'FAIL'} ({r['directives']} directives, {len(r['errors'])} errors)")
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
