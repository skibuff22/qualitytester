#!/usr/bin/env python3
"""
deploy_service.py — copy a committed tree to a host over SSH, restart a unit, verify.

Reads DEPLOY_HOST, DEPLOY_USER, DEPLOY_KEY_PATH (and optional DEPLOY_ROOT) from .env.
Refuses a dirty git tree. Normalizes CRLF/BOM on text files before sending (the
#1 Windows→Linux deploy bug). Writes logs/deploy-<ts>.json.

Usage:
  py executions/deploy_service.py --paths app/ scripts/ [--service myapp] [--dry-run]
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

TEXT_EXT = {".py", ".sh", ".js", ".ts", ".json", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".md", ".txt", ".html", ".css", ".env.example", ".service", ".plist"}


def load_env(path=".env"):
    p = Path(path)
    if p.is_file():
        for raw in p.read_text(encoding="utf-8-sig").splitlines():
            if "=" in raw and not raw.lstrip().startswith("#"):
                k, _, v = raw.partition("=")
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def git(*args: str) -> str:
    return subprocess.run(["git", *args], check=True, capture_output=True, text=True).stdout.strip()


def normalize_tree(src: Path, dst: Path) -> int:
    """Copy src→dst, converting CRLF→LF and stripping BOM on text files. Returns files changed."""
    changed = 0
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        target = dst / rel
        if p.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        if p.suffix in TEXT_EXT:
            raw = p.read_bytes()
            fixed = raw.replace(b"\r\n", b"\n")
            if fixed.startswith(b"\xef\xbb\xbf"):
                fixed = fixed[3:]
            if fixed != raw:
                changed += 1
            target.write_bytes(fixed)
        else:
            shutil.copy2(p, target)
    return changed


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Deploy committed files over SSH")
    ap.add_argument("--paths", nargs="+", required=True)
    ap.add_argument("--service", help="systemd unit to restart (sudo systemctl restart <unit>)")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    load_env()

    missing = [k for k in ("DEPLOY_HOST", "DEPLOY_USER", "DEPLOY_KEY_PATH") if not os.environ.get(k)]
    if missing:
        print(f"[bad input] missing in .env: {', '.join(missing)}", file=sys.stderr)
        return 2
    if git("status", "--porcelain"):
        print("[refused] working tree is dirty — commit first; never deploy uncommitted code", file=sys.stderr)
        return 2
    commit = git("rev-parse", "--short", "HEAD")
    host, user, key = os.environ["DEPLOY_HOST"], os.environ["DEPLOY_USER"], os.environ["DEPLOY_KEY_PATH"]
    root = os.environ.get("DEPLOY_ROOT", "~/app")
    ssh = ["ssh", "-i", key, "-o", "BatchMode=yes", f"{user}@{host}"]

    staged = Path(tempfile.mkdtemp(prefix="deploy-"))
    normalized = 0
    for p in a.paths:
        src = Path(p)
        if not src.exists():
            print(f"[bad input] path not found: {p}", file=sys.stderr)
            return 2
        if src.is_dir():
            normalized += normalize_tree(src, staged / src.name)
        else:
            single = Path(tempfile.mkdtemp(prefix="deploy-file-"))
            shutil.copy2(src, single / src.name)
            normalized += normalize_tree(single, staged)
            shutil.rmtree(single, ignore_errors=True)

    log = {"commit": commit, "host": host, "paths": a.paths, "normalized_files": normalized,
           "service": a.service, "dry_run": a.dry_run, "started": time.strftime("%Y-%m-%dT%H:%M:%S")}
    steps = [["scp", "-i", key, "-r", *[str(staged / Path(p).name) for p in a.paths], f"{user}@{host}:{root}/"]]
    if a.service:
        steps.append([*ssh, f"sudo systemctl restart {a.service} && systemctl is-active {a.service}"])
    for cmd in steps:
        print("$", " ".join(cmd))
        if not a.dry_run:
            r = subprocess.run(cmd, capture_output=True, text=True)
            if r.returncode != 0:
                log["error"] = r.stderr.strip()[:500]
                print(r.stderr, file=sys.stderr)
                break
    log["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    Path("logs").mkdir(exist_ok=True)
    out = Path("logs") / f"deploy-{int(time.time())}.json"
    out.write_text(json.dumps(log, indent=2))
    shutil.rmtree(staged, ignore_errors=True)
    print(f"deployed {commit} → {host} ({'dry run' if a.dry_run else 'live'}); log: {out}")
    print("next: run executions/qa_website.py against the live health URL — not done until it prints PASS")
    return 0 if "error" not in log else 1


if __name__ == "__main__":
    sys.exit(main())
