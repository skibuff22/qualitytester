"""Run: py -m pytest executions/tests  (or: py executions/tests/test_lint_secrets.py)"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lint_secrets import scan  # noqa: E402

FAKE_STRIPE = "sk_live_" + "A1b2C3d4E5f6G7h8I9j0K1l2M3n4"   # lint-secrets: allow
FAKE_GH = "ghp_" + "abcdefghijklmnopqrstuvwxyz0123456789"      # lint-secrets: allow


def test_hardcoded_stripe_key_is_caught():
    with tempfile.TemporaryDirectory() as d:
        (Path(d) / "pay.py").write_text(f'stripe.api_key = "{FAKE_STRIPE}"\n')
        r = scan(Path(d))
        assert not r["ok"] and r["findings"][0]["type"] == "stripe live secret"


def test_github_token_in_markdown_is_caught():
    with tempfile.TemporaryDirectory() as d:
        (Path(d) / "notes.md").write_text(f"token: {FAKE_GH}\n")
        assert not scan(Path(d))["ok"]


def test_env_file_itself_is_skipped_but_must_be_gitignored():
    with tempfile.TemporaryDirectory() as d:
        (Path(d) / ".env").write_text(f"STRIPE_SECRET_KEY={FAKE_STRIPE}\n")
        r = scan(Path(d))
        assert not r["findings"] and r["warnings"], r
        (Path(d) / ".gitignore").write_text(".env\n")
        assert scan(Path(d))["ok"]


def test_allow_marker_whitelists_line():
    with tempfile.TemporaryDirectory() as d:
        (Path(d) / "fixture.py").write_text(f'KEY = "{FAKE_STRIPE}"  # lint-secrets: allow\n')
        assert scan(Path(d))["ok"]


def test_env_reference_is_fine():
    with tempfile.TemporaryDirectory() as d:
        (Path(d) / "pay.py").write_text('stripe.api_key = os.environ["STRIPE_SECRET_KEY"]\n')
        assert scan(Path(d))["ok"]


def test_kit_itself_is_clean():
    assert scan(Path(__file__).resolve().parents[2])["ok"]


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok ", name)
    print("all tests passed")
