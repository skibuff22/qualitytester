"""Run: py -m pytest executions/tests  (or: py executions/tests/test_lint_directives.py)"""
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lint_directives import lint  # noqa: E402

GOOD = """# Directive: x
## Goal
g
## Inputs
i
## Execution tools
1. `executions/do_thing.py`
## Outputs
o
## Edge cases & learnings
e
## Verification
v
"""


def make_repo(tmp: Path, directive: str = GOOD, scripts=("do_thing.py",), claude: str | None = None) -> Path:
    (tmp / "directives").mkdir()
    (tmp / "directives" / "do_thing.md").write_text(directive, encoding="utf-8")
    (tmp / "executions").mkdir()
    for s in scripts:
        (tmp / "executions" / s).write_text("print('hi')\n")
    if claude is not None:
        (tmp / "CLAUDE.md").write_text(claude, encoding="utf-8")
    return tmp


def test_good_repo_passes():
    with tempfile.TemporaryDirectory() as d:
        r = lint(make_repo(Path(d), claude="see directives/do_thing.md"))
        assert r["ok"], r


def test_missing_section_fails():
    with tempfile.TemporaryDirectory() as d:
        r = lint(make_repo(Path(d), directive=GOOD.replace("## Verification\nv\n", "")))
        assert not r["ok"] and any("Verification" in e for e in r["errors"])


def test_missing_script_fails():
    with tempfile.TemporaryDirectory() as d:
        r = lint(make_repo(Path(d), scripts=()))
        assert any("does not exist" in e for e in r["errors"])


def test_orphan_script_fails():
    with tempfile.TemporaryDirectory() as d:
        r = lint(make_repo(Path(d), scripts=("do_thing.py", "orphan.py")))
        assert any("orphan" in e for e in r["errors"])


def test_claude_md_dangling_directive_fails():
    with tempfile.TemporaryDirectory() as d:
        r = lint(make_repo(Path(d), claude="read directives/nope.md"))
        assert any("nope.md" in e for e in r["errors"])


def test_kit_itself_passes():
    r = lint(Path(__file__).resolve().parents[2])
    assert r["ok"], r["errors"]


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok ", name)
    print("all tests passed")
