#!/usr/bin/env python3
"""
anneal.py — record one self-anneal entry (Root cause → Fix → Test → Standard).

Appends a dated entry to docs/anneal-log.md and, optionally, to the Edge-cases
section of a directive, so the learning lands where the next agent will read it.
Refuses entries that have no test or no root cause — that's the standard.

Usage:
  py executions/anneal.py --failure "blob trigger stopped firing" \
     --root-cause "deploy rotated the Event Grid webhook key; deliveries 401" \
     --fix "deploy script refreshes the key" \
     --test "executions/tests/test_deploy.py::test_webhook_key_refreshed" \
     --standard "directives/examples/deploy_service.md: deploy refreshes webhook key" \
     [--directive directives/examples/deploy_service.md] [--recovery "reprocessed 42 stuck docs"]
"""
from __future__ import annotations

import argparse
import datetime as dt
import re
import sys
from pathlib import Path


def format_entry(a: argparse.Namespace, today: str) -> str:
    lines = [f"### {today} — {a.failure}",
             f"- **Root cause:** {a.root_cause}",
             f"- **Fix:** {a.fix}",
             f"- **Test:** `{a.test}`",
             f"- **Standard:** {a.standard}"]
    if a.recovery:
        lines.append(f"- **Recovery (after fix):** {a.recovery}")
    return "\n".join(lines) + "\n\n"


def append_to_directive(path: Path, line: str) -> bool:
    text = path.read_text(encoding="utf-8")
    m = re.search(r"^## Edge cases[^\n]*\n", text, re.M)
    if not m:
        return False
    nxt = re.search(r"^## ", text[m.end():], re.M)
    insert_at = m.end() + (nxt.start() if nxt else len(text[m.end():]))
    block = text[m.end():insert_at].rstrip("\n") + "\n" + line + "\n\n"
    path.write_text(text[:m.end()] + block + text[insert_at:], encoding="utf-8")
    return True


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Record a self-anneal entry")
    for name in ("failure", "root-cause", "fix", "test", "standard"):
        ap.add_argument(f"--{name}", required=True)
    ap.add_argument("--recovery")
    ap.add_argument("--directive", help="directive file to append a one-line learning to")
    ap.add_argument("--root", default=".")
    a = ap.parse_args(argv)

    for field in ("root_cause", "test"):
        v = getattr(a, field).strip().lower()
        if len(v) < 8 or v in {"unknown", "n/a", "none", "tbd"}:
            print(f"[refused] --{field.replace('_', '-')} must name something real; a fix without it is incomplete", file=sys.stderr)
            return 2

    root = Path(a.root).resolve()
    today = dt.date.today().isoformat()
    log = root / "docs" / "anneal-log.md"
    log.parent.mkdir(parents=True, exist_ok=True)
    if not log.exists():
        log.write_text("# Self-anneal log\n\nEvery entry: root cause → fix → test → standard. Newest first.\n\n", encoding="utf-8")
    text = log.read_text(encoding="utf-8")
    head, _, rest = text.partition("\n\n")
    marker = "Every entry: root cause → fix → test → standard. Newest first.\n\n"
    if marker in text:
        pre, post = text.split(marker, 1)
        log.write_text(pre + marker + format_entry(a, today) + post, encoding="utf-8")
    else:
        log.write_text(text + format_entry(a, today), encoding="utf-8")
    print(f"recorded in {log.relative_to(root)}")

    if a.directive:
        d = root / a.directive
        line = f"- {today} — {a.failure} → {a.root_cause} → {a.fix}. Test: `{a.test}`"
        if d.is_file() and append_to_directive(d, line):
            print(f"appended learning to {a.directive}")
        else:
            print(f"[warn] could not append to {a.directive} (missing file or no '## Edge cases' section)", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
