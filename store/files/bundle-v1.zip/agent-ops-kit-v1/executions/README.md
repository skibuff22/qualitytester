# executions/

Deterministic tools (Layer 3). The agent runs these; it does not re-implement them.

| Script | Purpose | Directive |
|---|---|---|
| `00_template.py` | Scaffold for a new tool (argparse, .env, retries, exit codes, JSON) | — |
| `lint_directives.py` | Directives ↔ scripts consistency; CLAUDE.md paths exist | run in CI |
| `lint_secrets.py` | Hard-coded credential scan; `.env` must be gitignored | run pre-commit |
| `anneal.py` | Record a root-cause → fix → test → standard entry | `directives/core/self-annealing-loop.md` |
| `qa_website.py` | Headless QA + SEO check, crawls same-origin links | `directives/examples/qa_website.md` |
| `deploy_service.py` | scp + restart + normalize CRLF/BOM, refuses dirty tree | `directives/examples/deploy_service.md` |
| `scrape_website.py` | URLs → CSV/JSON, robots-aware, backoff, selector drift detection | `directives/examples/scrape_website.md` |
| `tests/` | Tests for the linters (and the kit's own compliance) | — |

Conventions:
- Windows: `py executions/x.py`; elsewhere `python3 executions/x.py`.
- Exit codes: 0 ok · 1 failure · 2 bad input · 3 external/API error.
- Secrets from `.env` only. Never print them.
- Every script has a `--help` that an agent can read instead of the source.

Pre-commit (copy to `.git/hooks/pre-commit`, make executable):
```sh
#!/bin/sh
python3 executions/lint_secrets.py && python3 executions/lint_directives.py
```
