#!/usr/bin/env python3
"""
scrape_website.py — URLs in, clean rows out. Static pages via requests+BeautifulSoup.

Usage:
  py executions/scrape_website.py --urls urls.txt --fields "title=h1,price=.price" --out data.csv [--delay 1.5]

Respects robots.txt (skips disallowed URLs as status=blocked), backs off on 403/429,
dedupes on normalized URL, exits 3 if >20% of pages yield no data for a field
(markup changed — inspect one page and fix the selector).

Requires: pip install requests beautifulsoup4
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
import urllib.robotparser as robotparser
from datetime import datetime, timezone
from urllib.parse import urlparse, urlunparse, parse_qsl, urlencode

TRACKING = {"utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "fbclid", "gclid"}


def normalize(url: str) -> str:
    u = urlparse(url.strip())
    q = urlencode([(k, v) for k, v in parse_qsl(u.query) if k not in TRACKING])
    return urlunparse((u.scheme.lower(), u.netloc.lower(), u.path.rstrip("/") or "/", "", q, ""))


def parse_fields(spec: str) -> dict[str, str]:
    out = {}
    for part in spec.split(","):
        if "=" not in part:
            raise SystemExit(f"[bad input] field spec '{part}' must be name=selector")
        k, v = part.split("=", 1)
        out[k.strip()] = v.strip()
    return out


def fetch(session, url: str, tries: int = 3):
    delay = 2.0
    for attempt in range(1, tries + 1):
        resp = session.get(url, timeout=20)
        if resp.status_code in (403, 429) and attempt < tries:
            time.sleep(delay)
            delay *= 2
            continue
        return resp
    return resp


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Scrape URLs into structured rows")
    ap.add_argument("--urls", required=True, help="file with one URL per line")
    ap.add_argument("--fields", required=True, help='e.g. "title=h1,price=.price"')
    ap.add_argument("--out", required=True, help=".csv or .json")
    ap.add_argument("--delay", type=float, default=1.5)
    ap.add_argument("--user-agent", default="agent-ops-kit scrape/1.0 (+contact in .env SCRAPER_CONTACT)")
    a = ap.parse_args(argv)

    try:
        import requests
        from bs4 import BeautifulSoup
    except ImportError:
        print("pip install requests beautifulsoup4", file=sys.stderr)
        return 2

    fields = parse_fields(a.fields)
    with open(a.urls, encoding="utf-8") as f:
        urls = list(dict.fromkeys(normalize(l) for l in f if l.strip() and not l.startswith("#")))

    session = requests.Session()
    session.headers["User-Agent"] = a.user_agent
    robots: dict[str, robotparser.RobotFileParser] = {}
    rows, empty_counts = [], {k: 0 for k in fields}

    for url in urls:
        host = urlparse(url).scheme + "://" + urlparse(url).netloc
        if host not in robots:
            rp = robotparser.RobotFileParser(host + "/robots.txt")
            try:
                rp.read()
            except Exception:  # noqa: BLE001
                rp = None
            robots[host] = rp
        row = {"url": url, "fetched_at": datetime.now(timezone.utc).isoformat(timespec="seconds"), "status": "ok"}
        if robots[host] is not None and not robots[host].can_fetch(a.user_agent, url):
            row["status"] = "blocked"
            rows.append(row)
            print(f"blocked  {url}")
            continue
        try:
            resp = fetch(session, url)
            if resp.status_code >= 400:
                row["status"] = f"http_{resp.status_code}"
            else:
                resp.encoding = resp.encoding or "utf-8"
                soup = BeautifulSoup(resp.text, "html.parser")
                for name, sel in fields.items():
                    el = soup.select_one(sel)
                    val = el.get_text(" ", strip=True) if el else ""
                    if not val:
                        empty_counts[name] += 1
                    row[name] = val
        except Exception as e:  # noqa: BLE001
            row["status"] = "error"
            row["error"] = str(e)[:200]
        rows.append(row)
        print(f"{row['status']:8} {url}")
        time.sleep(a.delay)

    if a.out.endswith(".json"):
        with open(a.out, "w", encoding="utf-8") as f:
            json.dump(rows, f, indent=2, ensure_ascii=False)
    else:
        cols = ["url", "fetched_at", "status", *fields, "error"]
        with open(a.out, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            w.writerows(rows)

    fetched = sum(1 for r in rows if r["status"] == "ok")
    print(f"wrote {len(rows)} rows ({fetched} ok) to {a.out}")
    for name, n in empty_counts.items():
        if fetched and n / fetched > 0.2:
            first = next((r["url"] for r in rows if r["status"] == "ok" and not r.get(name)), "?")
            print(f"[selector] '{name}' empty on {n}/{fetched} pages — markup changed? first: {first}", file=sys.stderr)
            return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
