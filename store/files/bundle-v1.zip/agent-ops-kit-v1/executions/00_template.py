#!/usr/bin/env python3
"""
Execution-script template (Layer 3 of D.O.E.).

Copy to executions/<job>.py and fill in run(). Everything an orchestrating agent
needs from a tool is already here:

  * argparse with --json for machine-readable output
  * .env loading (no python-dotenv dependency required)
  * structured logging to stderr, results to stdout
  * explicit exit codes: 0 ok, 1 failure, 2 bad input, 3 external/API error
  * one place to put retries/backoff for flaky calls

Usage:  py executions/<job>.py --example value [--json]
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Callable

EXIT_OK, EXIT_FAIL, EXIT_BAD_INPUT, EXIT_EXTERNAL = 0, 1, 2, 3

log = logging.getLogger(Path(__file__).stem)


def load_env(path: str | os.PathLike = ".env") -> dict[str, str]:
    """Load KEY=VALUE lines into os.environ (existing env wins). Returns what was loaded."""
    loaded: dict[str, str] = {}
    p = Path(path)
    if not p.is_file():
        return loaded
    for raw in p.read_text(encoding="utf-8-sig").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = val
            loaded[key] = val
    return loaded


def require_env(*names: str) -> dict[str, str]:
    missing = [n for n in names if not os.environ.get(n)]
    if missing:
        raise SystemExit(f"[bad input] missing env vars: {', '.join(missing)} (put them in .env)")
    return {n: os.environ[n] for n in names}


def retry(fn: Callable[[], Any], tries: int = 3, base_delay: float = 2.0, what: str = "call") -> Any:
    """Exponential backoff for flaky external calls. Re-raises the last error."""
    last: Exception | None = None
    for attempt in range(1, tries + 1):
        try:
            return fn()
        except Exception as e:  # noqa: BLE001 - deliberate: we re-raise after retries
            last = e
            if attempt == tries:
                break
            delay = base_delay * (2 ** (attempt - 1))
            log.warning("%s failed (%s); retry %d/%d in %.0fs", what, e, attempt, tries - 1, delay)
            time.sleep(delay)
    assert last is not None
    raise last


def run(args: argparse.Namespace) -> dict[str, Any]:
    """Do the deterministic work. Return a JSON-serializable result dict."""
    # Example:
    # cfg = require_env("MY_API_KEY")
    # data = retry(lambda: call_api(cfg["MY_API_KEY"], args.example), what="my api")
    return {"ok": True, "example": args.example}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--example", required=True, help="an input the directive tells the agent to supply")
    parser.add_argument("--json", action="store_true", help="print result as JSON (for the agent)")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(levelname)s %(name)s: %(message)s", stream=sys.stderr)
    load_env()

    try:
        result = run(args)
    except SystemExit as e:  # bad input raised above
        print(str(e), file=sys.stderr)
        return EXIT_BAD_INPUT
    except Exception as e:  # noqa: BLE001
        log.error("failed: %s", e, exc_info=args.verbose)
        print(json.dumps({"ok": False, "error": str(e)}) if args.json else f"[fail] {e}")
        return EXIT_EXTERNAL

    print(json.dumps(result, indent=2) if args.json else result)
    return EXIT_OK if result.get("ok", True) else EXIT_FAIL


if __name__ == "__main__":
    sys.exit(main())
