# Agent Ops Kit + Publish Gate bundle (v1)

Two kits from Calyx AI (Quality Tester Solutions LLC), unchanged from the single products:

- agent-ops-kit-v1/  - the 3-layer framework (directives, orchestration, execution) for
  Claude Code, Cursor and Codex. Start with agent-ops-kit-v1/START-HERE.md.
- publish-gate-v1/   - the pre-publish gate for AI-assisted posts (facts file, voice guide,
  verify_post.py, publishers that refuse unverified drafts). Start with
  publish-gate-v1/START-HERE.md.

Each folder keeps its own LICENSE.txt. Support: tdoane@calyx-ai.net
